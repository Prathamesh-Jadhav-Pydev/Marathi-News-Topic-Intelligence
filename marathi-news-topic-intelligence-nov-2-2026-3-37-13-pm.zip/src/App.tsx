/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { SidebarNav } from './components/SidebarNav';
import { DashboardView } from './components/DashboardView';
import { GenerateView } from './components/GenerateView';
import { TopicLibraryView } from './components/TopicLibraryView';
import { TopicDetailDrawer } from './components/TopicDetailDrawer';
import { ResearchSourcesView } from './components/ResearchSourcesView';
import { ImportExportView } from './components/ImportExportView';
import { CategoryManagerView } from './components/CategoryManagerView';

import { TopicRecord, BatchMetadata, WorkflowStatus, ImportedRecord } from './types';
import { topicDB } from './services/db';
import { INITIAL_SAMPLE_TOPICS } from './services/sampleData';

export default function App() {
  const [topics, setTopics] = useState<TopicRecord[]>([]);
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [selectedTopic, setSelectedTopic] = useState<TopicRecord | null>(null);
  const [dbConnected, setDbConnected] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Initialize DB and load topics
  useEffect(() => {
    async function loadInitialData() {
      try {
        let storedTopics = await topicDB.getAllTopics();

        // If IndexedDB is empty, pre-seed realistic Marathi sample records
        if (storedTopics.length === 0) {
          await topicDB.saveTopicsBulk(INITIAL_SAMPLE_TOPICS);
          storedTopics = INITIAL_SAMPLE_TOPICS;
        }

        setTopics(storedTopics);
        setDbConnected(true);
      } catch (err) {
        console.error('Failed to load topic data from IndexedDB:', err);
        setTopics(INITIAL_SAMPLE_TOPICS);
      } finally {
        setIsLoading(false);
      }
    }

    loadInitialData();
  }, []);

  // Update topic in state and IndexedDB
  const handleUpdateTopic = async (updatedTopic: TopicRecord) => {
    setTopics(prev => prev.map(t => t.topic_id === updatedTopic.topic_id ? updatedTopic : t));
    if (selectedTopic?.topic_id === updatedTopic.topic_id) {
      setSelectedTopic(updatedTopic);
    }
    await topicDB.saveTopic(updatedTopic);
  };

  // Update single topic status
  const handleUpdateTopicStatus = async (topicId: string, newStatus: WorkflowStatus) => {
    const existing = topics.find(t => t.topic_id === topicId);
    if (!existing) return;

    const updated: TopicRecord = {
      ...existing,
      workflow_status: newStatus,
      last_updated_at: new Date().toISOString(),
    };

    await handleUpdateTopic(updated);
  };

  // Delete single topic
  const handleDeleteTopic = async (topicId: string) => {
    setTopics(prev => prev.filter(t => t.topic_id !== topicId));
    if (selectedTopic?.topic_id === topicId) {
      setSelectedTopic(null);
    }
    await topicDB.deleteTopic(topicId);
  };

  // Bulk update status
  const handleBulkUpdateStatus = async (topicIds: string[], newStatus: WorkflowStatus) => {
    const updatedList = topics.map(t => {
      if (topicIds.includes(t.topic_id)) {
        return {
          ...t,
          workflow_status: newStatus,
          last_updated_at: new Date().toISOString(),
        };
      }
      return t;
    });

    setTopics(updatedList);
    const modified = updatedList.filter(t => topicIds.includes(t.topic_id));
    await topicDB.saveTopicsBulk(modified);
  };

  // Bulk delete
  const handleBulkDelete = async (topicIds: string[]) => {
    setTopics(prev => prev.filter(t => !topicIds.includes(t.topic_id)));
    for (const id of topicIds) {
      await topicDB.deleteTopic(id);
    }
  };

  // Callback when batch generation completes
  const handleBatchCompleted = (newTopics: TopicRecord[], batchMeta: BatchMetadata) => {
    setTopics(prev => {
      // Merge unique new topics
      const existingIds = new Set(prev.map(t => t.topic_id));
      const filteredNew = newTopics.filter(t => !existingIds.has(t.topic_id));
      return [...filteredNew, ...prev];
    });
  };

  // Callback for import
  const handleImportCompleted = (importedRecords: ImportedRecord[]) => {
    // Optionally refresh view or notify
  };

  const pendingReviewCount = topics.filter(t => t.workflow_status === 'under_review' || t.workflow_status === 'idea').length;
  const duplicateCount = topics.filter(t => t.duplicate_status === 'confirmed_duplicate').length;

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-950 text-white flex items-center justify-center font-sans">
        <div className="text-center space-y-3">
          <div className="w-10 h-10 border-4 border-amber-500 border-t-transparent rounded-full animate-spin mx-auto" />
          <p className="text-sm font-bold text-amber-400">मराठी वृत्त विषय बुद्धिमत्ता सुरू होत आहे...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-amber-500 selection:text-slate-950">
      {/* Top Header */}
      <Header
        topics={topics}
        dbStatus={dbConnected}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        searchQuery={searchQuery}
        onSearchChange={(q) => {
          setSearchQuery(q);
          if (q && activeTab !== 'library') {
            setActiveTab('library');
          }
        }}
      />

      <div className="flex-1 flex flex-col md:flex-row max-w-7xl w-full mx-auto">
        {/* Navigation Sidebar */}
        <SidebarNav
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          pendingReviewCount={pendingReviewCount}
          duplicateCount={duplicateCount}
        />

        {/* Main Content Workspace */}
        <main className="flex-1 p-4 sm:p-6 overflow-y-auto">
          {activeTab === 'dashboard' && (
            <DashboardView
              topics={topics}
              setActiveTab={setActiveTab}
              onSelectTopic={(t) => setSelectedTopic(t)}
            />
          )}

          {activeTab === 'generate' && (
            <GenerateView
              existingTopics={topics}
              onBatchCompleted={handleBatchCompleted}
              setActiveTab={setActiveTab}
            />
          )}

          {activeTab === 'library' && (
            <TopicLibraryView
              topics={topics}
              onSelectTopic={(t) => setSelectedTopic(t)}
              onUpdateTopicStatus={handleUpdateTopicStatus}
              onDeleteTopic={handleDeleteTopic}
              onBulkUpdateStatus={handleBulkUpdateStatus}
              onBulkDelete={handleBulkDelete}
              searchQuery={searchQuery}
              onSearchQueryChange={setSearchQuery}
            />
          )}

          {activeTab === 'sources' && (
            <ResearchSourcesView
              topics={topics}
              onSelectTopic={(t) => setSelectedTopic(t)}
            />
          )}

          {activeTab === 'import-export' && (
            <ImportExportView
              topics={topics}
              onImportCompleted={handleImportCompleted}
            />
          )}

          {activeTab === 'categories' && (
            <CategoryManagerView />
          )}
        </main>
      </div>

      {/* Slide-over Topic Detail Drawer */}
      <TopicDetailDrawer
        topic={selectedTopic}
        onClose={() => setSelectedTopic(null)}
        onUpdateTopic={handleUpdateTopic}
      />
    </div>
  );
}
