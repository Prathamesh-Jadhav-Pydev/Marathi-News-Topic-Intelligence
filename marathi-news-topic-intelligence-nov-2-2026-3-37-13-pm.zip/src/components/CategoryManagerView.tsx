import React, { useState } from 'react';
import { FolderTree, Plus, Trash2, CheckCircle2, RotateCcw, Power, Search } from 'lucide-react';
import { PRIMARY_CATEGORIES } from '../constants/categories';
import { CategoryId, CategoryDef } from '../types';
import { topicDB } from '../services/db';

export const CategoryManagerView: React.FC = () => {
  const [categories, setCategories] = useState<CategoryDef[]>(PRIMARY_CATEGORIES);
  const [customSubcategories, setCustomSubcategories] = useState<Record<string, string[]>>(() => {
    const init: Record<string, string[]> = {};
    PRIMARY_CATEGORIES.forEach(c => {
      init[c.id] = [...c.subcategories];
    });
    return init;
  });

  const [searchFilter, setSearchFilter] = useState<string>('');
  const [newSubInput, setNewSubInput] = useState<Record<string, string>>({});
  const [saveStatusMsg, setSaveStatusMsg] = useState<string | null>(null);

  const handleToggleCategoryDisabled = (catId: CategoryId) => {
    setCategories(prev => prev.map(c => c.id === catId ? { ...c, isDisabled: !c.isDisabled } : c));
  };

  const handleAddSubcategory = (catId: CategoryId) => {
    const inputVal = (newSubInput[catId] || '').trim();
    if (!inputVal) return;

    if (!customSubcategories[catId]?.includes(inputVal)) {
      setCustomSubcategories({
        ...customSubcategories,
        [catId]: [...(customSubcategories[catId] || []), inputVal],
      });
      setNewSubInput({ ...newSubInput, [catId]: '' });
    }
  };

  const handleRemoveSubcategory = (catId: CategoryId, subName: string) => {
    setCustomSubcategories({
      ...customSubcategories,
      [catId]: (customSubcategories[catId] || []).filter(s => s !== subName),
    });
  };

  const handleSaveSubcategories = async () => {
    await topicDB.saveSetting('custom_subcategories', customSubcategories);
    await topicDB.saveSetting('categories_config', categories);
    setSaveStatusMsg('✅ सर्व ३० श्रेणी व सब-कॅटेगरी सेटिंग्ज यशस्वीरीत्या जतन केल्या!');
    setTimeout(() => setSaveStatusMsg(null), 4000);
  };

  const handleResetDefaults = () => {
    const init: Record<string, string[]> = {};
    PRIMARY_CATEGORIES.forEach(c => {
      init[c.id] = [...c.subcategories];
    });
    setCustomSubcategories(init);
    setCategories(PRIMARY_CATEGORIES);
  };

  const filteredCategories = categories.filter(c =>
    c.marathiLabel.toLowerCase().includes(searchFilter.toLowerCase()) ||
    c.englishLabel.toLowerCase().includes(searchFilter.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-slate-800/90 border border-slate-700/80 rounded-2xl p-6 shadow-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <FolderTree className="w-5 h-5 text-amber-400" />
            <h2 className="text-lg font-bold text-white">
              ३० संपादकीय श्रेणी व सब-कॅटेगरी व्यवस्थापक (Taxonomy Manager)
            </h2>
          </div>
          <p className="text-xs text-slate-300 mt-1">
            मूलभूत १२ + नवीन १८ (एकूण ३०) श्रेणी आणि सब-कॅटेगरी व्यवस्थापित करा, सक्रिय/निष्क्रीय करा व उप-विभाग जोडा.
          </p>
        </div>

        <div className="flex items-center space-x-2 text-xs">
          <button
            onClick={handleResetDefaults}
            className="bg-slate-700 hover:bg-slate-600 text-slate-200 px-3 py-2 rounded-lg font-bold transition-colors flex items-center space-x-1"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>रीसेट करा</span>
          </button>

          <button
            onClick={handleSaveSubcategories}
            className="bg-amber-500 hover:bg-amber-600 text-slate-950 px-4 py-2 rounded-lg font-bold transition-colors flex items-center space-x-1"
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>बदल सेव्ह करा</span>
          </button>
        </div>
      </div>

      {saveStatusMsg && (
        <div className="bg-emerald-950/40 border border-emerald-800/80 rounded-xl p-3 text-xs text-emerald-300 font-bold">
          {saveStatusMsg}
        </div>
      )}

      {/* Filter Bar */}
      <div className="relative max-w-sm">
        <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 transform -translate-y-1/2" />
        <input
          type="text"
          placeholder="श्रेणी शोधा (Search 30 categories...)"
          value={searchFilter}
          onChange={(e) => setSearchFilter(e.target.value)}
          className="w-full bg-slate-900 border border-slate-700 text-white rounded-xl pl-9 pr-4 py-2 text-xs focus:border-amber-500 focus:outline-none"
        />
      </div>

      {/* Grid of 30 Categories */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredCategories.map((cat) => {
          const subs = customSubcategories[cat.id] || [];

          return (
            <div
              key={cat.id}
              className={`bg-slate-800/80 border rounded-2xl p-4 space-y-3 shadow-lg flex flex-col justify-between transition-all ${
                cat.isDisabled ? 'opacity-50 border-rose-800/40' : 'border-slate-700/60'
              }`}
            >
              <div>
                <div className="flex items-center justify-between border-b border-slate-700/60 pb-2">
                  <div>
                    <div className="font-bold text-white text-sm flex items-center space-x-2">
                      <span>{cat.marathiLabel}</span>
                      {cat.isHealthCategory && (
                        <span className="bg-rose-500/20 text-rose-300 text-[10px] px-1.5 py-0.2 rounded border border-rose-500/30">
                          वैद्यकीय
                        </span>
                      )}
                    </div>
                    <div className="text-xs text-slate-400">{cat.englishLabel}</div>
                  </div>

                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => handleToggleCategoryDisabled(cat.id)}
                      className={`p-1.5 rounded-lg border text-xs transition-colors ${
                        cat.isDisabled
                          ? 'bg-rose-950 text-rose-300 border-rose-800'
                          : 'bg-emerald-950 text-emerald-300 border-emerald-800'
                      }`}
                      title={cat.isDisabled ? 'सक्रिय करा' : 'निष्क्रीय करा'}
                    >
                      <Power className="w-3.5 h-3.5" />
                    </button>
                    <span className="text-[10px] text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20 font-bold">
                      {subs.length} उप-श्रेणी
                    </span>
                  </div>
                </div>

                <p className="text-[11px] text-slate-400 mt-2 line-clamp-2">{cat.description}</p>

                {/* Subcategories List */}
                <div className="mt-3 space-y-1.5 max-h-40 overflow-y-auto pr-1">
                  {subs.map((s) => (
                    <div
                      key={s}
                      className="flex items-center justify-between bg-slate-900/60 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-200"
                    >
                      <span className="truncate">{s}</span>
                      <button
                        onClick={() => handleRemoveSubcategory(cat.id, s)}
                        className="text-slate-500 hover:text-rose-400 p-0.5"
                        title="हटवा"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Add Subcategory Input */}
              <div className="mt-3 pt-2 border-t border-slate-700/60 flex items-center space-x-2">
                <input
                  type="text"
                  placeholder="नवीन सब-कॅटेगरी जोडा..."
                  value={newSubInput[cat.id] || ''}
                  onChange={(e) => setNewSubInput({ ...newSubInput, [cat.id]: e.target.value })}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') handleAddSubcategory(cat.id);
                  }}
                  className="flex-1 bg-slate-900 border border-slate-700 text-white rounded-lg px-2.5 py-1.5 text-xs focus:border-amber-500 focus:outline-none"
                />
                <button
                  onClick={() => handleAddSubcategory(cat.id)}
                  className="bg-amber-500 hover:bg-amber-600 text-slate-950 p-1.5 rounded-lg transition-colors"
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
