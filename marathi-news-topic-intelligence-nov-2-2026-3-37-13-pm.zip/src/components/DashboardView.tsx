import React from 'react';
import {
  Sparkles,
  CheckCircle2,
  Clock,
  Search,
  BookOpen,
  FileText,
  AlertTriangle,
  ArrowRight,
  ShieldCheck,
  Zap,
  BarChart2,
  Heart
} from 'lucide-react';
import { TopicRecord, CategoryId } from '../types';
import { PRIMARY_CATEGORIES } from '../constants/categories';

interface DashboardViewProps {
  topics: TopicRecord[];
  setActiveTab: (tab: string) => void;
  onSelectTopic: (topic: TopicRecord) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  topics,
  setActiveTab,
  onSelectTopic,
}) => {
  // Calculated Metrics from actual stored records
  const totalGenerated = topics.length;
  const uniqueTopics = topics.filter(t => t.duplicate_status === 'unique').length;
  const awaitingReview = topics.filter(t => t.workflow_status === 'under_review' || t.workflow_status === 'idea').length;
  const researchBacked = topics.filter(t => t.research_status === 'verified').length;
  const howToAndGuides = topics.filter(t => t.search_intent_type === 'explainer' || t.search_intent_type === 'informational').length;
  const evergreenTopics = topics.filter(t => t.evergreen_or_trending === 'evergreen').length;
  const approvedForWriting = topics.filter(t => t.workflow_status === 'approved').length;
  const duplicatesAndRejected = topics.filter(
    t => t.duplicate_status === 'confirmed_duplicate' || t.workflow_status === 'rejected'
  ).length;

  // Category counts
  const categoryCounts: Record<CategoryId, number> = PRIMARY_CATEGORIES.reduce((acc, cat) => {
    acc[cat.id] = topics.filter(t => t.primary_category === cat.id).length;
    return acc;
  }, {} as Record<CategoryId, number>);

  // Priority counts
  const highPriorityCount = topics.filter(t => t.editorial_priority === 'high').length;
  const medPriorityCount = topics.filter(t => t.editorial_priority === 'medium').length;
  const lowPriorityCount = topics.filter(t => t.editorial_priority === 'low').length;

  // Recent 6 blog topics
  const recentTopics = [...topics]
    .filter(t => t.workflow_status !== 'rejected')
    .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
    .slice(0, 6);

  return (
    <div className="space-y-6">
      {/* Welcome Banner & Quick Action */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 border border-slate-700/80 rounded-2xl p-6 shadow-xl relative overflow-hidden">
        <div className="absolute right-0 top-0 bottom-0 w-1/3 bg-gradient-to-l from-amber-500/10 to-transparent pointer-events-none" />
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 relative z-10">
          <div>
            <div className="flex items-center space-x-2">
              <span className="px-2.5 py-1 rounded-md text-xs font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center space-x-1">
                <Heart className="w-3.5 h-3.5 text-amber-400" />
                <span>मानवकेंद्रित ब्लॉग विषय बुद्धिमत्ता</span>
              </span>
              <span className="text-xs text-slate-400">| Human-Centric & Reader-First Blog Strategy</span>
            </div>
            <h2 className="text-2xl font-black text-white mt-2 tracking-tight">
              वाचककेंद्रित ब्लॉग विषय व सोल्यूशन्स डॅशबोर्ड
            </h2>
            <p className="text-sm text-slate-300 mt-1 max-w-2xl">
              सामान्य वाचकांच्या दैनंदिन समस्या, शंका, हाउ-टू गरजा, जीवनशैली पर्याय आणि खरेदी निर्णयांशी सुसंगत परिपूर्ण १०० ब्लॉग विषयांची निर्मिती.
            </p>
          </div>

          <button
            onClick={() => setActiveTab('generate')}
            className="shrink-0 bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white font-bold px-5 py-3 rounded-xl shadow-lg shadow-orange-500/20 hover:shadow-orange-500/30 flex items-center space-x-2 transition-all transform hover:-translate-y-0.5"
          >
            <Sparkles className="w-5 h-5" />
            <span>नवीन १०० ब्लॉग विषय जनरेट करा</span>
            <ArrowRight className="w-4 h-4 ml-1" />
          </button>
        </div>
      </div>

      {/* 8 Essential Metrics Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
        <div className="bg-slate-800/80 border border-slate-700/60 rounded-xl p-3.5 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>एकूण ब्लॉग</span>
            <FileText className="w-4 h-4 text-blue-400" />
          </div>
          <div className="text-2xl font-black text-white mt-2">{totalGenerated}</div>
          <div className="text-[10px] text-slate-400 mt-1">Total Blog Topics</div>
        </div>

        <div className="bg-slate-800/80 border border-slate-700/60 rounded-xl p-3.5 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>युनिक विषय</span>
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-black text-emerald-400 mt-2">{uniqueTopics}</div>
          <div className="text-[10px] text-slate-400 mt-1">Unique Topics</div>
        </div>

        <div className="bg-slate-800/80 border border-slate-700/60 rounded-xl p-3.5 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>प्रतीक्षेत</span>
            <Clock className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-black text-amber-400 mt-2">{awaitingReview}</div>
          <div className="text-[10px] text-slate-400 mt-1">Awaiting Review</div>
        </div>

        <div className="bg-slate-800/80 border border-slate-700/60 rounded-xl p-3.5 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>संशोधित</span>
            <Search className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-2xl font-black text-cyan-400 mt-2">{researchBacked}</div>
          <div className="text-[10px] text-slate-400 mt-1">Research Backed</div>
        </div>

        <div className="bg-slate-800/80 border border-slate-700/60 rounded-xl p-3.5 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>हाउ-टू / गाईड्स</span>
            <BookOpen className="w-4 h-4 text-orange-400" />
          </div>
          <div className="text-2xl font-black text-orange-400 mt-2">{howToAndGuides}</div>
          <div className="text-[10px] text-slate-400 mt-1">How-To & Guides</div>
        </div>

        <div className="bg-slate-800/80 border border-slate-700/60 rounded-xl p-3.5 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>सदाबहार SEO</span>
            <Zap className="w-4 h-4 text-purple-400" />
          </div>
          <div className="text-2xl font-black text-purple-400 mt-2">{evergreenTopics}</div>
          <div className="text-[10px] text-slate-400 mt-1">Evergreen SEO</div>
        </div>

        <div className="bg-slate-800/80 border border-slate-700/60 rounded-xl p-3.5 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>लेखनासाठी स्वीकृत</span>
            <CheckCircle2 className="w-4 h-4 text-teal-400" />
          </div>
          <div className="text-2xl font-black text-teal-400 mt-2">{approvedForWriting}</div>
          <div className="text-[10px] text-slate-400 mt-1">Approved for Writing</div>
        </div>

        <div className="bg-slate-800/80 border border-slate-700/60 rounded-xl p-3.5 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>ड्युप्लिकेट / बाद</span>
            <AlertTriangle className="w-4 h-4 text-rose-400" />
          </div>
          <div className="text-2xl font-black text-rose-400 mt-2">{duplicatesAndRejected}</div>
          <div className="text-[10px] text-slate-400 mt-1">Duplicate/Rejected</div>
        </div>
      </div>

      {/* Main Grid: Category Distribution & Priority Queue */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Category Distribution (2 Cols) */}
        <div className="lg:col-span-2 bg-slate-800/80 border border-slate-700/60 rounded-2xl p-5 shadow-lg">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-2">
              <BarChart2 className="w-5 h-5 text-amber-400" />
              <h3 className="text-base font-bold text-white">
                ३० श्रेणींमधील ब्लॉग विषयांचे वितरण (Blog Category Distribution)
              </h3>
            </div>
            <button
              onClick={() => setActiveTab('library')}
              className="text-xs text-amber-400 hover:text-amber-300 font-medium flex items-center space-x-1"
            >
              <span>ग्रंथालयात सर्व पाहा</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 max-h-96 overflow-y-auto pr-1">
            {PRIMARY_CATEGORIES.map((cat) => {
              const count = categoryCounts[cat.id] || 0;
              const percentage = totalGenerated > 0 ? Math.round((count / totalGenerated) * 100) : 0;

              return (
                <div
                  key={cat.id}
                  onClick={() => setActiveTab('library')}
                  className="bg-slate-900/60 border border-slate-700/50 rounded-xl p-3 hover:border-amber-500/50 transition-all cursor-pointer group"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-200 group-hover:text-amber-400 transition-colors truncate">
                      {cat.marathiLabel}
                    </span>
                    <span className="text-[10px] text-slate-400 truncate">{cat.englishLabel}</span>
                  </div>
                  <div className="flex items-baseline space-x-2 mt-2">
                    <span className="text-xl font-black text-white">{count}</span>
                    <span className="text-xs text-slate-400 font-medium">विषय ({percentage}%)</span>
                  </div>
                  <div className="w-full bg-slate-800 rounded-full h-1.5 mt-2 overflow-hidden">
                    <div
                      className="bg-gradient-to-r from-amber-500 to-orange-500 h-1.5 rounded-full"
                      style={{ width: `${Math.min(100, Math.max(5, percentage))}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Priority & Workflow Summary Card */}
        <div className="bg-slate-800/80 border border-slate-700/60 rounded-2xl p-5 shadow-lg flex flex-col justify-between">
          <div>
            <h3 className="text-base font-bold text-white mb-3">
              ब्लॉग प्राधान्य क्रम (Blog Priority Breakdown)
            </h3>

            <div className="space-y-3">
              <div className="bg-rose-950/30 border border-rose-800/40 rounded-xl p-3 flex items-center justify-between">
                <div>
                  <div className="text-xs font-bold text-rose-300">उच्च प्राधान्य (High Priority)</div>
                  <div className="text-[10px] text-slate-400">वाचकांच्या तात्कालिक व मोठ्या समस्या</div>
                </div>
                <div className="text-2xl font-black text-rose-400">{highPriorityCount}</div>
              </div>

              <div className="bg-amber-950/30 border border-amber-800/40 rounded-xl p-3 flex items-center justify-between">
                <div>
                  <div className="text-xs font-bold text-amber-300">मध्यम प्राधान्य (Medium Priority)</div>
                  <div className="text-[10px] text-slate-400">सदाबहार हाउ-टू व तुलनात्मक गाईड्स</div>
                </div>
                <div className="text-2xl font-black text-amber-400">{medPriorityCount}</div>
              </div>

              <div className="bg-slate-900/60 border border-slate-700/50 rounded-xl p-3 flex items-center justify-between">
                <div>
                  <div className="text-xs font-bold text-slate-300">साधारण प्राधान्य (Low Priority)</div>
                  <div className="text-[10px] text-slate-400">सामान्य माहितीपूर्ण ब्लॉग लेख</div>
                </div>
                <div className="text-2xl font-black text-slate-400">{lowPriorityCount}</div>
              </div>
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-slate-700/60">
            <div className="flex justify-between items-center text-xs text-slate-400 mb-2">
              <span>एकूण डेटाबेस वापर:</span>
              <span className="font-bold text-slate-200">{totalGenerated} / १०० मानक बॅच</span>
            </div>
            <button
              onClick={() => setActiveTab('library')}
              className="w-full bg-slate-700 hover:bg-slate-600 text-white font-medium text-xs py-2.5 rounded-lg text-center transition-colors flex items-center justify-center space-x-1"
            >
              <BookOpen className="w-4 h-4" />
              <span>ब्लॉग ग्रंथालयात जाऊन रिव्ह्यू करा</span>
            </button>
          </div>
        </div>
      </div>

      {/* Recent Topic Feed */}
      <div className="bg-slate-800/80 border border-slate-700/60 rounded-2xl p-5 shadow-lg">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-2">
            <Clock className="w-5 h-5 text-amber-400" />
            <h3 className="text-base font-bold text-white">
              ताजे जनरेट झालेले ब्लॉग विषय (Recent Blog Opportunity Feed)
            </h3>
          </div>
          <button
            onClick={() => setActiveTab('library')}
            className="text-xs text-amber-400 hover:text-amber-300 font-medium flex items-center space-x-1"
          >
            <span>सर्व {topics.length} ब्लॉग विषय पाहा</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {recentTopics.length === 0 ? (
          <div className="text-center py-10 text-slate-400">
            <p>कोणतेही विषय उपलब्ध नाहीत. "१०० ब्लॉग विषय जनरेट करा" बटणावर क्लिक करून नवीन बॅच सुरू करा.</p>
          </div>
        ) : (
          <div className="divide-y divide-slate-700/60">
            {recentTopics.map((topic) => {
              const catDef = PRIMARY_CATEGORIES.find(c => c.id === topic.primary_category);

              return (
                <div
                  key={topic.topic_id}
                  onClick={() => onSelectTopic(topic)}
                  className="py-3.5 flex flex-col md:flex-row md:items-center justify-between gap-3 hover:bg-slate-700/30 px-3 rounded-xl transition-all cursor-pointer group"
                >
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center space-x-2 mb-1">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${catDef?.color || 'bg-slate-800 text-slate-300 border-slate-700'}`}>
                        {catDef?.marathiLabel || topic.primary_category}
                      </span>
                      <span className="text-[11px] text-slate-400">/ {topic.subcategory}</span>
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-900 text-slate-400 border border-slate-700">
                        🌲 सदाबहार ब्लॉग
                      </span>
                    </div>

                    <h4 className="text-sm font-bold text-white group-hover:text-amber-400 transition-colors line-clamp-1">
                      {topic.primary_headline}
                    </h4>

                    <p className="text-xs text-slate-400 line-clamp-1 mt-0.5">
                      {topic.topic_summary}
                    </p>
                  </div>

                  <div className="flex items-center space-x-3 shrink-0 text-xs">
                    <div className="text-right hidden sm:block">
                      <div className="text-[10px] text-slate-400">प्रायमरी कीवर्ड:</div>
                      <div className="text-xs font-semibold text-slate-200">{topic.primary_keyword}</div>
                    </div>

                    <span className={`px-2 py-1 rounded text-xs font-bold ${
                      topic.editorial_priority === 'high'
                        ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                        : topic.editorial_priority === 'medium'
                        ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                        : 'bg-slate-700 text-slate-300'
                    }`}>
                      {topic.editorial_priority === 'high' ? 'उच्च प्राधान्य' : topic.editorial_priority === 'medium' ? 'मध्यम' : 'साधारण'}
                    </span>

                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onSelectTopic(topic);
                      }}
                      className="bg-slate-700 hover:bg-amber-500 hover:text-slate-950 text-slate-200 px-3 py-1.5 rounded-lg font-medium text-xs transition-colors"
                    >
                      ब्रिफ पाहा
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
