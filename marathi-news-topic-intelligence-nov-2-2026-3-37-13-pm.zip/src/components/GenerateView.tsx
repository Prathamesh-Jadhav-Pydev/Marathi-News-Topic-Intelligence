import React, { useState } from 'react';
import {
  Sparkles,
  CheckSquare,
  Square,
  Play,
  Sliders,
  Layers,
  Filter,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
  Heart,
  ShieldCheck,
  Ban,
  FileText,
  HelpCircle
} from 'lucide-react';
import {
  BatchSettings,
  CategoryId,
  TopicRecord,
  BatchMetadata,
  TopicMixOption,
  ResearchMode,
  GeoFocus,
  TopicFocusOption
} from '../types';
import { PRIMARY_CATEGORIES, TOPIC_MIX_OPTIONS, GEO_FOCUS_OPTIONS, TOPIC_FOCUS_OPTIONS } from '../constants/categories';
import { DEFAULT_GEMINI_MODEL_LABEL } from '../constants/config';
import { checkDuplicateStatus, detectCategoryMismatch } from '../services/dedup';
import { topicDB } from '../services/db';
import { safeFetchJson } from '../utils/apiClient';

interface GenerateViewProps {
  existingTopics: TopicRecord[];
  onBatchCompleted: (newTopics: TopicRecord[], batchMeta: BatchMetadata) => void;
  setActiveTab: (tab: string) => void;
}

// Blacklisted political, breaking news, election, and event-centric keywords for strict human-centric filtering
const POLITICAL_NEWS_KEYWORDS = [
  'निवडणूक', 'निवडणुका', 'राजकारण', 'राजकीय', 'नेता', 'नेते', 'मंत्री', 'मुख्यमंत्री',
  'पंतप्रधान', 'आमदार', 'खासदार', 'पक्ष', 'काँग्रेस', 'भाजप', 'शिवसेना', 'राष्ट्रवादी',
  'अधिवेशन', 'घोटाळा', 'आंदोलन', 'मोर्चा', 'संप', 'स्ट्राइक', 'पोलिस', 'गुन्हेगारी',
  'क्राईम', 'उमेदवार', 'निकाल', 'दंगल', 'अटक', 'कोर्ट', 'न्यायालय', 'सुनावणी', 'विरोधी',
  'सभेत', 'विपक्ष', 'भाषण', 'घोषणा', 'ब्रेकिंग', 'न्यूज', 'बातमी', 'ताजी', 'घडामोडी',
  'election', 'political', 'politics', 'minister', 'government announcement',
  'breaking news', 'crime', 'scam', 'police arrest', 'court order'
];

/**
 * Validates whether a candidate topic is reader-first and free of political/news-centric keywords.
 */
function isPoliticalOrNewsCentric(topic: Partial<TopicRecord>): { isRejected: boolean; reason?: string } {
  const textToScan = [
    topic.primary_headline || '',
    topic.topic_title || '',
    topic.topic_summary || '',
    topic.primary_keyword || '',
    ...(topic.alternate_headlines || []),
    ...(topic.secondary_keywords || [])
  ].join(' ').toLowerCase();

  for (const keyword of POLITICAL_NEWS_KEYWORDS) {
    if (textToScan.includes(keyword.toLowerCase())) {
      return {
        isRejected: true,
        reason: `राजकीय किंवा बातमी-केंद्रित शब्द आढळला ('${keyword}')`
      };
    }
  }

  return { isRejected: false };
}

export const GenerateView: React.FC<GenerateViewProps> = ({
  existingTopics,
  onBatchCompleted,
  setActiveTab,
}) => {
  // Form State
  const [selectedCategories, setSelectedCategories] = useState<CategoryId[]>(
    PRIMARY_CATEGORIES.map(c => c.id)
  );

  const [expandedCategory, setExpandedCategory] = useState<CategoryId | null>(null);

  const [categorySubcategories, setCategorySubcategories] = useState<Record<string, string[]>>(() => {
    const init: Record<string, string[]> = {};
    PRIMARY_CATEGORIES.forEach(c => {
      init[c.id] = [...c.subcategories];
    });
    return init;
  });

  const [batchSize, setBatchSize] = useState<number>(100);
  const [topicMix, setTopicMix] = useState<TopicMixOption>('evergreen');
  const [topicFocus, setTopicFocus] = useState<TopicFocusOption>('all');
  const [researchMode, setResearchMode] = useState<ResearchMode>('deep');
  const [geoFocus, setGeoFocus] = useState<GeoFocus>('maharashtra');
  const [customGeo, setCustomGeo] = useState<string>('');
  const [audienceFocus, setAudienceFocus] = useState<string>('सामान्य मराठी वाचक, गृहिणी, नोकरदार व कुटुंब');
  const [seedKeywordsText, setSeedKeywordsText] = useState<string>('');
  const [excludedSubjectsText, setExcludedSubjectsText] = useState<string>('राजकारण, निवडणुका, ब्रेकिंग न्यूज, गुन्हेगारी, राजकीय वाद');
  const [customInstructionsText, setCustomInstructionsText] = useState<string>('');

  // Generation Execution State
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [currentBatchMeta, setCurrentBatchMeta] = useState<BatchMetadata | null>(null);
  const [generatedBatchTopics, setGeneratedBatchTopics] = useState<TopicRecord[]>([]);
  const [logs, setLogs] = useState<string[]>([]);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Toggle Category Selection
  const toggleCategory = (catId: CategoryId) => {
    if (selectedCategories.includes(catId)) {
      if (selectedCategories.length === 1) return; // Keep at least 1
      setSelectedCategories(selectedCategories.filter(id => id !== catId));
    } else {
      setSelectedCategories([...selectedCategories, catId]);
    }
  };

  const selectAllCategories = () => {
    setSelectedCategories(PRIMARY_CATEGORIES.map(c => c.id));
  };

  const clearAllCategories = () => {
    setSelectedCategories([PRIMARY_CATEGORIES[0].id]);
  };

  // Category Allocation Plan Matrix
  const allocationPlan = React.useMemo(() => {
    const count = selectedCategories.length;
    if (count === 0) return {};

    const basePerCat = Math.floor(batchSize / count);
    let remainder = batchSize % count;

    const plan: Record<string, number> = {};
    selectedCategories.forEach((catId) => {
      plan[catId] = basePerCat + (remainder > 0 ? 1 : 0);
      if (remainder > 0) remainder--;
    });
    return plan;
  }, [selectedCategories, batchSize]);

  const addLog = (msg: string) => {
    const timestamp = new Date().toLocaleTimeString();
    setLogs(prev => [`[${timestamp}] ${msg}`, ...prev]);
  };

  // Core Batch Generation Execution Engine with Political/News Filtering
  const startBatchGeneration = async () => {
    setErrorMessage(null);
    setIsGenerating(true);
    setLogs([]);
    setGeneratedBatchTopics([]);

    const batchId = `batch-${Date.now()}`;
    const seedKeywords = seedKeywordsText.split(',').map(s => s.trim()).filter(Boolean);
    
    // Automatically enforce political & news exclusions
    const defaultExclusions = ['राजकारण', 'निवडणुका', 'ब्रेकिंग न्यूज', 'गुन्हेगारी', 'राजकीय वाद'];
    const userExclusions = excludedSubjectsText.split(',').map(s => s.trim()).filter(Boolean);
    const combinedExclusions = Array.from(new Set([...defaultExclusions, ...userExclusions]));

    const settings: BatchSettings = {
      batch_id: batchId,
      categories: selectedCategories,
      subcategories: categorySubcategories,
      batch_size: batchSize,
      topic_mix: topicMix,
      topic_focus: topicFocus,
      research_mode: researchMode,
      geo_focus: geoFocus,
      custom_geo: customGeo,
      audience_focus: audienceFocus,
      seed_keywords: seedKeywords,
      excluded_subjects: combinedExclusions,
      custom_instructions: customInstructionsText,
      language: 'mr',
    };

    const initialBatchMeta: BatchMetadata = {
      batch_id: batchId,
      created_at: new Date().toISOString(),
      settings,
      requested_count: batchSize,
      generated_count: 0,
      verified_count: 0,
      duplicate_rejected_count: 0,
      malformed_rejected_count: 0,
      replacement_generated_count: 0,
      status: 'running',
      current_stage: 'वाचककेंद्रित वर्गवारी व राजकीय/बातमी फिल्टर प्लॅन तयार करत आहे...',
      logs: [],
    };

    setCurrentBatchMeta(initialBatchMeta);
    addLog(`वाचककेंद्रित ब्लॉग बॅच सुरू केली [ID: ${batchId}] - लक्ष्य: ${batchSize} ब्लॉग विषय`);
    if (customInstructionsText.trim()) {
      addLog(`📝 सानुकूल सूचना (Custom Instructions) लागू: "${customInstructionsText.trim().slice(0, 60)}..."`);
    }
    addLog(`🛡️ राजकीय व बातमी-केंद्रित विषय आपोआप फिल्टर केले जातील.`);
    addLog(`निवडलेल्या ३० पैकी श्रेणी: ${selectedCategories.map(c => PRIMARY_CATEGORIES.find(p => p.id === c)?.marathiLabel).join(', ')}`);

    const importedRecords = await topicDB.getAllImportedRecords();

    let accumulatedTopics: TopicRecord[] = [];
    let duplicateRejected = 0;
    let malformedRejected = 0;
    let replacementsCount = 0;

    const chunkSize = 10;
    const totalChunksNeeded = Math.ceil(batchSize / chunkSize);

    try {
      for (let chunkIdx = 0; chunkIdx < totalChunksNeeded; chunkIdx++) {
        if (accumulatedTopics.length >= batchSize) break;

        const neededCount = Math.min(chunkSize, batchSize - accumulatedTopics.length);
        const stageMessage = `ब्लॉग चंक ${chunkIdx + 1}/${totalChunksNeeded} जनरेट करत आहे (${neededCount} वाचककेंद्रित विषय)...`;

        setCurrentBatchMeta(prev => prev ? { ...prev, current_stage: stageMessage } : null);
        addLog(stageMessage);

        // Pacing delay between chunk requests to respect API rate limits
        if (chunkIdx > 0) {
          await new Promise(res => setTimeout(res, 500));
        }

        const chunkData = await safeFetchJson<{ topics: TopicRecord[] }>('/api/generate-chunk', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            categories: selectedCategories,
            subcategories: categorySubcategories,
            count: neededCount,
            topic_mix: topicMix,
            topic_focus: topicFocus,
            research_mode: researchMode,
            geo_focus: geoFocus === 'custom' ? customGeo : geoFocus,
            audience_focus: audienceFocus,
            seed_keywords: seedKeywords,
            excluded_subjects: combinedExclusions,
            custom_instructions: customInstructionsText,
            batch_id: batchId,
            existing_headlines: [
              ...existingTopics.map(t => t.primary_headline),
              ...accumulatedTopics.map(t => t.primary_headline)
            ]
          }),
        });

        const rawChunkTopics: TopicRecord[] = chunkData.topics || [];

        addLog(`चंक ${chunkIdx + 1} मधून ${rawChunkTopics.length} ब्लॉग विषय प्राप्त झाले. गुणवत्त्ता व फिल्टर पडताळणी चालू...`);

        for (const candidate of rawChunkTopics) {
          if (accumulatedTopics.length >= batchSize) break;

          // 1. Explicit Political & News-Centric Filter Check
          const politicalCheck = isPoliticalOrNewsCentric(candidate);
          if (politicalCheck.isRejected) {
            duplicateRejected++;
            addLog(`⛔ राजकीय/बातमी विषय फिल्टर झाला: "${candidate.primary_headline?.slice(0, 35)}..." (${politicalCheck.reason})`);
            continue;
          }

          // 2. Deduplication check
          const dedupResult = checkDuplicateStatus(
            candidate,
            [...existingTopics, ...accumulatedTopics],
            importedRecords
          );

          if (dedupResult.duplicate_status === 'confirmed_duplicate') {
            duplicateRejected++;
            addLog(`❌ ड्युप्लिकेट म्हणून बाद केले: "${candidate.primary_headline?.slice(0, 35)}..."`);
            continue;
          }

          // 3. Category compatibility check
          const categoryMismatch = detectCategoryMismatch(
            candidate.primary_headline || candidate.topic_title || '',
            candidate.primary_category
          );

          if (categoryMismatch) {
            addLog(`⚠️ श्रेणी इशारा: "${candidate.primary_headline?.slice(0, 30)}..."`);
          }

          const validatedTopic: TopicRecord = {
            ...candidate,
            duplicate_status: dedupResult.duplicate_status,
            duplicate_matches: dedupResult.matches,
            category_mismatch_warning: categoryMismatch || candidate.category_mismatch_warning,
          };

          accumulatedTopics.push(validatedTopic);
          setGeneratedBatchTopics([...accumulatedTopics]);

          const verifiedCount = accumulatedTopics.filter(t => t.research_status === 'verified').length;

          setCurrentBatchMeta(prev => prev ? {
            ...prev,
            generated_count: accumulatedTopics.length,
            verified_count: verifiedCount,
            duplicate_rejected_count: duplicateRejected,
            malformed_rejected_count: malformedRejected,
            replacement_generated_count: replacementsCount
          } : null);
        }

        // Generate replacements if needed to reach exact target count
        if (accumulatedTopics.length < batchSize && chunkIdx === totalChunksNeeded - 1 && duplicateRejected > 0) {
          const missingCount = batchSize - accumulatedTopics.length;
          addLog(`बॅच लक्ष्य पूर्ण करण्यासाठी ${missingCount} रिप्लेसमेंट वाचककेंद्रित ब्लॉग विषय जनरेट करत आहे...`);
          replacementsCount += missingCount;

          try {
            const repData = await safeFetchJson<{ topics: TopicRecord[] }>('/api/generate-chunk', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                categories: selectedCategories,
                subcategories: categorySubcategories,
                count: missingCount,
                topic_mix: topicMix,
                topic_focus: topicFocus,
                research_mode: researchMode,
                geo_focus: geoFocus,
                audience_focus: audienceFocus,
                excluded_subjects: combinedExclusions,
                custom_instructions: customInstructionsText,
                batch_id: batchId,
                existing_headlines: accumulatedTopics.map(t => t.primary_headline)
              }),
            });

            const repTopics: TopicRecord[] = repData.topics || [];
            for (const rTopic of repTopics) {
              if (accumulatedTopics.length >= batchSize) break;
              if (isPoliticalOrNewsCentric(rTopic).isRejected) continue;
              accumulatedTopics.push(rTopic);
              setGeneratedBatchTopics([...accumulatedTopics]);
            }
          } catch (repErr: any) {
            addLog(`⚠️ रिप्लेसमेंट जनरेशन इशारा: ${repErr.message}`);
          }
        }
      }

      await topicDB.saveTopicsBulk(accumulatedTopics);

      const finalVerifiedCount = accumulatedTopics.filter(t => t.research_status === 'verified').length;
      const finalMeta: BatchMetadata = {
        batch_id: batchId,
        created_at: new Date().toISOString(),
        settings,
        requested_count: batchSize,
        generated_count: accumulatedTopics.length,
        verified_count: finalVerifiedCount,
        duplicate_rejected_count: duplicateRejected,
        malformed_rejected_count: malformedRejected,
        replacement_generated_count: replacementsCount,
        status: 'completed',
        current_stage: `पूर्ण झाले: ${accumulatedTopics.length}/${batchSize} वाचककेंद्रित ब्लॉग विषय यशस्वीरीत्या जतन केले.`,
        logs,
      };

      await topicDB.saveBatchMetadata(finalMeta);
      setCurrentBatchMeta(finalMeta);
      setIsGenerating(false);

      addLog(`🎉 १०० वाचककेंद्रित ब्लॉग विषयांची बॅच यशस्वीरीत्या पूर्ण झाली! [एकूण जतन: ${accumulatedTopics.length}]`);
      onBatchCompleted(accumulatedTopics, finalMeta);

    } catch (err: any) {
      console.error('Batch Generation Error:', err);
      const msg = err.message || 'जनरेशन दरम्यान अनपेक्षित त्रुटी आली';
      setErrorMessage(msg);
      addLog(`🚨 त्रुटी: ${msg}`);

      if (accumulatedTopics.length > 0) {
        await topicDB.saveTopicsBulk(accumulatedTopics);
        addLog(`⚠️ आंशिक परिणाम (${accumulatedTopics.length} विषय) डेटाबेसमध्ये सुरक्षित जतन केले आहेत.`);
      }

      setIsGenerating(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Title Header */}
      <div className="bg-slate-800/90 border border-slate-700/80 rounded-2xl p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <Heart className="w-5 h-5 text-amber-400" />
            <h2 className="text-xl font-bold text-white">
              १०० वाचककेंद्रित ब्लॉग विषय जनरेटर (Human-Centric Blog Topic Engine)
            </h2>
          </div>
          <p className="text-xs text-slate-300 mt-1">
            बातम्या आणि राजकीय घडामोडींऐवजी सामान्य माणसांच्या रोजच्या समस्या, हाउ-टू गरजा, जीवनशैली पर्याय आणि निर्णयांवर आधारित १०० दीर्घकालीन ब्लॉग विषय.
          </p>
        </div>

        <div className="flex items-center space-x-3">
          {isGenerating ? (
            <div className="flex items-center space-x-2 bg-amber-500/20 text-amber-300 border border-amber-500/30 px-4 py-2 rounded-xl text-xs font-bold animate-pulse">
              <Sparkles className="w-4 h-4 animate-spin" />
              <span>ब्लॉग जनरेशन चालू आहे... ({generatedBatchTopics.length}/{batchSize})</span>
            </div>
          ) : (
            <button
              onClick={startBatchGeneration}
              className="bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white font-bold px-6 py-3 rounded-xl shadow-lg shadow-orange-500/25 flex items-center space-x-2 text-sm transition-all transform hover:-translate-y-0.5"
            >
              <Play className="w-4 h-4 fill-white" />
              <span>१०० वाचककेंद्रित ब्लॉग जनरेट करा</span>
            </button>
          )}
        </div>
      </div>

      {/* Reader-First Protection Banner & Model Information */}
      <div className="bg-emerald-950/40 border border-emerald-800/60 rounded-xl p-3.5 flex flex-wrap items-center justify-between gap-2 text-xs text-emerald-300">
        <div className="flex items-center space-x-2">
          <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>
            <strong>वाचककेंद्रित सुरक्षा फिल्टर सक्रिय:</strong> राजकीय घडामोडी, ब्रेकिंग न्यूज व गुन्हेगारी बातम्या आपोआप गाळल्या जातील.
          </span>
        </div>
        <div className="flex items-center space-x-2">
          <span className="bg-slate-900/80 text-amber-300 border border-amber-500/30 px-2.5 py-0.5 rounded text-[10px] font-bold">
            🤖 Engine: {DEFAULT_GEMINI_MODEL_LABEL}
          </span>
          <span className="bg-emerald-900/60 text-emerald-200 px-2 py-0.5 rounded text-[10px] font-bold border border-emerald-700">
            Reader-First Active
          </span>
        </div>
      </div>

      {/* Grid: Left Settings (2 Cols) | Right Category Allocation Matrix (1 Col) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Settings Panel */}
        <div className="lg:col-span-2 space-y-6">
          {/* 1. Category & Subcategory Selector */}
          <div className="bg-slate-800/80 border border-slate-700/60 rounded-2xl p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-700/60 pb-3">
              <div>
                <h3 className="text-sm font-bold text-white flex items-center space-x-2">
                  <Layers className="w-4 h-4 text-amber-400" />
                  <span>ब्लॉग श्रेणी निवडा (Select Blog Categories)</span>
                </h3>
                <p className="text-[11px] text-slate-400">३० उपलब्ध श्रेणींपैकी आवश्यक श्रेणी निवडा</p>
              </div>

              <div className="flex items-center space-x-2 text-xs">
                <button
                  onClick={selectAllCategories}
                  className="text-amber-400 hover:underline font-medium"
                >
                  सर्व निवडा (30)
                </button>
                <span className="text-slate-600">|</span>
                <button
                  onClick={clearAllCategories}
                  className="text-slate-400 hover:text-slate-200"
                >
                  क्लियर
                </button>
              </div>
            </div>

            {/* Category Cards */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 max-h-80 overflow-y-auto pr-1">
              {PRIMARY_CATEGORIES.map((cat) => {
                const isSelected = selectedCategories.includes(cat.id);
                const isExpanded = expandedCategory === cat.id;

                return (
                  <div
                    key={cat.id}
                    className={`border rounded-xl p-3 transition-all ${
                      isSelected
                        ? 'bg-slate-900/90 border-amber-500/60 shadow-md shadow-amber-500/5'
                        : 'bg-slate-900/40 border-slate-800 opacity-60 hover:opacity-100'
                    }`}
                  >
                    <div className="flex items-center justify-between cursor-pointer" onClick={() => toggleCategory(cat.id)}>
                      <div className="flex items-center space-x-2 min-w-0">
                        {isSelected ? (
                          <CheckSquare className="w-4 h-4 text-amber-400 shrink-0" />
                        ) : (
                          <Square className="w-4 h-4 text-slate-500 shrink-0" />
                        )}
                        <span className={`text-xs font-bold truncate ${isSelected ? 'text-amber-300' : 'text-slate-300'}`}>
                          {cat.marathiLabel}
                        </span>
                      </div>

                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setExpandedCategory(isExpanded ? null : cat.id);
                        }}
                        className="text-slate-400 hover:text-slate-200 p-1"
                      >
                        {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                      </button>
                    </div>

                    <div className="text-[10px] text-slate-400 mt-1 flex justify-between">
                      <span className="truncate">{cat.englishLabel}</span>
                      <span className="font-bold text-amber-400/80 shrink-0 ml-1">~{allocationPlan[cat.id] || 0} विषय</span>
                    </div>

                    {isExpanded && (
                      <div className="mt-2 pt-2 border-t border-slate-800 text-[11px] space-y-1">
                        <div className="font-semibold text-slate-300 text-[10px]">सब-कॅटेगरी:</div>
                        {cat.subcategories.map(sub => (
                          <div key={sub} className="text-slate-400 flex items-center space-x-1.5 pl-1">
                            <div className="w-1 h-1 rounded-full bg-amber-400" />
                            <span className="truncate">{sub}</span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* 2. Generation Engine Controls */}
          <div className="bg-slate-800/80 border border-slate-700/60 rounded-2xl p-5 space-y-4">
            <h3 className="text-sm font-bold text-white border-b border-slate-700/60 pb-3 flex items-center space-x-2">
              <Sliders className="w-4 h-4 text-amber-400" />
              <span>ब्लॉग सेटिंग्ज व सर्च निकष (Blog Criteria)</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              {/* Batch Size */}
              <div>
                <label className="block text-slate-300 font-medium mb-1">
                  बॅच संख्या (Batch Size)
                </label>
                <select
                  value={batchSize}
                  onChange={(e) => setBatchSize(parseInt(e.target.value, 10))}
                  className="w-full bg-slate-900 border border-slate-700 text-white rounded-lg px-3 py-2 focus:border-amber-500 focus:outline-none"
                >
                  <option value={100}>१०० ब्लॉग विषय (मानक पूर्ण बॅच)</option>
                  <option value={50}>५० ब्लॉग विषय</option>
                  <option value={20}>२० चाचणी विषय</option>
                </select>
              </div>

              {/* Topic Mix */}
              <div>
                <label className="block text-slate-300 font-medium mb-1">
                  ब्लॉग स्वरूप (Topic Mix)
                </label>
                <select
                  value={topicMix}
                  onChange={(e) => setTopicMix(e.target.value as TopicMixOption)}
                  className="w-full bg-slate-900 border border-slate-700 text-white rounded-lg px-3 py-2 focus:border-amber-500 focus:outline-none"
                >
                  <option value="evergreen">🌲 सदाबहार (Evergreen SEO Focus - दीर्घकालीन शोध मूल्य)</option>
                  <option value="balanced">संतुलित (सदाबहार व हंगामी मार्गदर्शक)</option>
                  <option value="seasonal">🎉 सण व हंगामी शॉपिंग/फॅशन आयडिया</option>
                </select>
              </div>

              {/* Topic Focus */}
              <div>
                <label className="block text-slate-300 font-medium mb-1 flex items-center space-x-1">
                  <Filter className="w-3.5 h-3.5 text-amber-400" />
                  <span>विषय आशय केंद्रितता (Topic Focus)</span>
                </label>
                <select
                  value={topicFocus}
                  onChange={(e) => setTopicFocus(e.target.value as TopicFocusOption)}
                  className="w-full bg-slate-900 border border-amber-500/50 text-amber-300 font-medium rounded-lg px-3 py-2 focus:border-amber-400 focus:outline-none"
                >
                  {TOPIC_FOCUS_OPTIONS.map((opt) => (
                    <option key={opt.id} value={opt.id}>
                      {opt.label} — {opt.description}
                    </option>
                  ))}
                </select>
              </div>

              {/* Research Mode */}
              <div>
                <label className="block text-slate-300 font-medium mb-1">
                  वाचक संशोधन मोड (Research Mode)
                </label>
                <select
                  value={researchMode}
                  onChange={(e) => setResearchMode(e.target.value as ResearchMode)}
                  className="w-full bg-slate-900 border border-slate-700 text-white rounded-lg px-3 py-2 focus:border-amber-500 focus:outline-none"
                >
                  <option value="deep">सखोल वाचक संशोधन (Google Search Grounding)</option>
                  <option value="standard">मानक ब्लॉग संशोधन (Standard Guide)</option>
                </select>
              </div>

              {/* Geo Focus */}
              <div>
                <label className="block text-slate-300 font-medium mb-1">
                  लक्षित वाचकवर्ग (Audience Region)
                </label>
                <select
                  value={geoFocus}
                  onChange={(e) => setGeoFocus(e.target.value as GeoFocus)}
                  className="w-full bg-slate-900 border border-slate-700 text-white rounded-lg px-3 py-2 focus:border-amber-500 focus:outline-none"
                >
                  {GEO_FOCUS_OPTIONS.map(opt => (
                    <option key={opt.id} value={opt.id}>{opt.label}</option>
                  ))}
                </select>
              </div>
            </div>

            {/* Seed Keywords & Exclusions */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div>
                <label className="block text-slate-300 font-medium mb-1">
                  सीड कीवर्ड्स (Seed Keywords)
                </label>
                <input
                  type="text"
                  placeholder="उदा. दिवाळी फॅशन, बचत योजना, गर्भारपण आहार"
                  value={seedKeywordsText}
                  onChange={(e) => setSeedKeywordsText(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 text-white rounded-lg px-3 py-2 focus:border-amber-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1 flex items-center justify-between">
                  <span>फिल्टर केलेले वर्ज्य विषय (Excluded Subjects)</span>
                  <Ban className="w-3.5 h-3.5 text-rose-400" />
                </label>
                <input
                  type="text"
                  placeholder="राजकारण, निवडणुका, ब्रेकिंग न्यूज, गुन्हेगारी, राजकीय वाद"
                  value={excludedSubjectsText}
                  onChange={(e) => setExcludedSubjectsText(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 text-white rounded-lg px-3 py-2 focus:border-amber-500 focus:outline-none"
                />
              </div>
            </div>

            {/* Custom Instructions (सानुकूल सूचना) */}
            <div className="pt-3 border-t border-slate-700/60 space-y-2 text-xs">
              <div className="flex items-center justify-between">
                <label className="text-slate-200 font-bold flex items-center space-x-1.5">
                  <FileText className="w-4 h-4 text-amber-400" />
                  <span>सानुकूल सूचना (Custom Instructions)</span>
                  <span className="text-[10px] text-slate-400 font-normal">(ऐच्छिक / Optional)</span>
                </label>
                {customInstructionsText && (
                  <button
                    onClick={() => setCustomInstructionsText('')}
                    className="text-[11px] text-amber-400 hover:underline"
                  >
                    सूचना साफ करा (Clear)
                  </button>
                )}
              </div>
              <p className="text-[11px] text-slate-400">
                विषयांची शैली, वाचकवर्ग, टोनेलिटी, सखोलता किंवा टाळावयाचे शब्द स्वतःच्या शब्दात स्पष्ट करा. Gemini जनरेशन इंजिन या सूचनांचे काटेकोर पालन करेल.
              </p>
              <textarea
                rows={3}
                placeholder="उदा. 'सदाबहार, मानवकेंद्रित ब्लॉग विषयांवर भर द्या. नवशिक्यांसाठी सोपी भाषा वापरा. राजकीय बातम्या व अफवा टाळा. दैनंदिन समस्यांवर कृतीशील आणि सोपे उपाय सुचवा.'"
                value={customInstructionsText}
                onChange={(e) => setCustomInstructionsText(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 text-white rounded-xl p-3 text-xs focus:border-amber-500 focus:outline-none placeholder:text-slate-500 leading-relaxed"
              />
              
              {/* Sample Custom Instruction Presets */}
              <div className="space-y-1.5 pt-1">
                <div className="text-[10px] font-semibold text-slate-400 flex items-center space-x-1">
                  <HelpCircle className="w-3 h-3 text-amber-400" />
                  <span>उदाहरणे व त्वरित सूचना प्रिसेट्स (Example Presets):</span>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  <button
                    type="button"
                    onClick={() => setCustomInstructionsText("Generate evergreen, human-centric blog topics. Focus on everyday problems, practical solutions, readers' questions and search intent. Avoid breaking news, announcements and newsroom-style headlines.")}
                    className="bg-slate-900 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 rounded-lg px-2.5 py-1 text-[10px] transition-colors"
                  >
                    🌱 Evergreen Human-Centric
                  </button>
                  <button
                    type="button"
                    onClick={() => setCustomInstructionsText("Target beginners. Use simple language and explain concepts step by step. Avoid technical jargon.")}
                    className="bg-slate-900 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 rounded-lg px-2.5 py-1 text-[10px] transition-colors"
                  >
                    🔰 Beginner-Friendly
                  </button>
                  <button
                    type="button"
                    onClick={() => setCustomInstructionsText("Prioritise informational search intent, long-tail keywords and specific topics that answer genuine search queries. Avoid keyword stuffing.")}
                    className="bg-slate-900 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 rounded-lg px-2.5 py-1 text-[10px] transition-colors"
                  >
                    🔍 SEO Informational
                  </button>
                  <button
                    type="button"
                    onClick={() => setCustomInstructionsText("Target young working professionals in India. Focus on practical, affordable and realistic recommendations.")}
                    className="bg-slate-900 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 rounded-lg px-2.5 py-1 text-[10px] transition-colors"
                  >
                    💼 Young Professionals
                  </button>
                  <button
                    type="button"
                    onClick={() => setCustomInstructionsText("Do not generate topics related to politics, celebrity gossip or breaking news.")}
                    className="bg-slate-900 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 rounded-lg px-2.5 py-1 text-[10px] transition-colors"
                  >
                    🚫 Exclude News & Politics
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Category Allocation Matrix Panel */}
        <div className="space-y-6">
          <div className="bg-slate-800/80 border border-slate-700/60 rounded-2xl p-5 shadow-lg space-y-4">
            <h3 className="text-sm font-bold text-white border-b border-slate-700/60 pb-3 flex items-center space-x-2">
              <Filter className="w-4 h-4 text-amber-400" />
              <span>१०० विषयांचे प्रस्तावित वाटप (Allocation Plan)</span>
            </h3>

            <div className="bg-slate-900/60 border border-slate-700/50 rounded-xl p-3 text-xs text-slate-300 space-y-2">
              <div className="flex justify-between font-bold text-amber-400">
                <span>एकूण उद्दिष्ट (Target):</span>
                <span>{batchSize} ब्लॉग विषय</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>निवडलेल्या श्रेणी:</span>
                <span>{selectedCategories.length} पैकी ३०</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>सरासरी प्रति श्रेणी:</span>
                <span>~{Math.round(batchSize / selectedCategories.length)} विषय</span>
              </div>
            </div>

            <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
              {selectedCategories.map((catId) => {
                const catDef = PRIMARY_CATEGORIES.find(c => c.id === catId);
                const count = allocationPlan[catId] || 0;

                return (
                  <div
                    key={catId}
                    className="flex items-center justify-between bg-slate-900/40 border border-slate-800 rounded-lg px-3 py-2 text-xs"
                  >
                    <div className="flex items-center space-x-2 truncate">
                      <div className="w-2 h-2 rounded-full bg-amber-400 shrink-0" />
                      <span className="font-semibold text-slate-200 truncate">{catDef?.marathiLabel}</span>
                    </div>
                    <span className="font-bold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">
                      {count} विषय
                    </span>
                  </div>
                );
              })}
            </div>

            <div className="pt-2">
              <button
                onClick={startBatchGeneration}
                disabled={isGenerating}
                className="w-full bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 disabled:opacity-50 text-white font-bold py-3 rounded-xl shadow-lg shadow-orange-500/20 text-xs flex items-center justify-center space-x-2 transition-all"
              >
                <Sparkles className="w-4 h-4" />
                <span>१०० वाचककेंद्रित ब्लॉग जनरेट करा</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Real-Time Progress Monitor & Live Execution Log */}
      {(isGenerating || currentBatchMeta) && (
        <div className="bg-slate-900 border border-amber-500/40 rounded-2xl p-6 shadow-2xl space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
            <div>
              <div className="flex items-center space-x-2">
                <span className="w-2.5 h-2.5 rounded-full bg-amber-400 animate-ping" />
                <h3 className="text-base font-bold text-white">
                  जनरेशन मॉनिटर [बॅच ID: {currentBatchMeta?.batch_id}]
                </h3>
              </div>
              <p className="text-xs text-amber-300 mt-1">
                {currentBatchMeta?.current_stage}
              </p>
            </div>

            <div className="flex items-center space-x-2 text-xs">
              <button
                onClick={() => setActiveTab('library')}
                className="bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold px-4 py-2 rounded-lg transition-colors"
              >
                ग्रंथालयात निकाल पाहा ({generatedBatchTopics.length})
              </button>
            </div>
          </div>

          {/* Progress Bar */}
          <div>
            <div className="flex justify-between text-xs font-bold text-slate-300 mb-1.5">
              <span>प्रगती (Progress):</span>
              <span className="text-amber-400">
                {generatedBatchTopics.length} / {batchSize} (
                {Math.round((generatedBatchTopics.length / batchSize) * 100)}%)
              </span>
            </div>
            <div className="w-full bg-slate-800 rounded-full h-3 overflow-hidden p-0.5 border border-slate-700">
              <div
                className="bg-gradient-to-r from-amber-500 via-orange-500 to-amber-400 h-full rounded-full transition-all duration-300"
                style={{ width: `${Math.min(100, (generatedBatchTopics.length / batchSize) * 100)}%` }}
              />
            </div>
          </div>

          {/* Real-time KPI Counters */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
            <div className="bg-slate-800/80 border border-slate-700/80 rounded-xl p-3">
              <div className="text-slate-400 text-[10px]">वैध ब्लॉग विषय:</div>
              <div className="text-xl font-bold text-emerald-400 mt-1">{generatedBatchTopics.length}</div>
            </div>

            <div className="bg-slate-800/80 border border-slate-700/80 rounded-xl p-3">
              <div className="text-slate-400 text-[10px]">संशोधित (Research Verified):</div>
              <div className="text-xl font-bold text-cyan-400 mt-1">{currentBatchMeta?.verified_count || 0}</div>
            </div>

            <div className="bg-slate-800/80 border border-slate-700/80 rounded-xl p-3">
              <div className="text-slate-400 text-[10px]">ड्युप्लिकेट व बातमी-फिल्टर बाद:</div>
              <div className="text-xl font-bold text-rose-400 mt-1">{currentBatchMeta?.duplicate_rejected_count || 0}</div>
            </div>

            <div className="bg-slate-800/80 border border-slate-700/80 rounded-xl p-3">
              <div className="text-slate-400 text-[10px]">रिप्लेसमेंट विषयांची भर:</div>
              <div className="text-xl font-bold text-amber-400 mt-1">{currentBatchMeta?.replacement_generated_count || 0}</div>
            </div>
          </div>

          {/* Error Alert */}
          {errorMessage && (
            <div className="bg-rose-950/40 border border-rose-800/80 rounded-xl p-4 text-xs text-rose-300 flex items-start space-x-2">
              <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
              <div>
                <div className="font-bold">सूचना:</div>
                <div>{errorMessage}</div>
              </div>
            </div>
          )}

          {/* Execution Log Stream */}
          <div>
            <div className="text-xs font-bold text-slate-400 mb-2 flex items-center justify-between">
              <span>लाइव्ह एक्झिक्युशन लॉग (Live Log):</span>
              <span className="text-[10px] text-slate-500">{logs.length} नोंदणी</span>
            </div>
            <div className="bg-slate-950 border border-slate-800 rounded-xl p-3 font-mono text-[11px] text-slate-300 max-h-48 overflow-y-auto space-y-1">
              {logs.map((log, idx) => (
                <div key={idx} className="leading-relaxed border-b border-slate-900/50 pb-0.5">
                  {log}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
