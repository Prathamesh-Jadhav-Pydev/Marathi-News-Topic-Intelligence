import React from 'react';
import { BookOpenText, Sparkles, CheckCircle2, Database, Globe, Layers, Search, X } from 'lucide-react';
import { TopicRecord } from '../types';

interface HeaderProps {
  topics: TopicRecord[];
  activeBatchId?: string;
  dbStatus: boolean;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  searchQuery?: string;
  onSearchChange?: (query: string) => void;
}

export const Header: React.FC<HeaderProps> = ({
  topics,
  activeBatchId,
  dbStatus,
  activeTab,
  setActiveTab,
  searchQuery = '',
  onSearchChange,
}) => {
  const totalCount = topics.length;
  const approvedCount = topics.filter(t => t.workflow_status === 'approved').length;
  const researchBackedCount = topics.filter(t => t.research_status === 'verified').length;

  return (
    <header className="bg-slate-900 border-b border-slate-800 text-white sticky top-0 z-30 shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-3">
          {/* Logo & Title */}
          <div className="flex items-center space-x-3 cursor-pointer shrink-0" onClick={() => setActiveTab('dashboard')}>
            <div className="w-10 h-10 rounded-lg bg-gradient-to-tr from-amber-500 to-orange-600 flex items-center justify-center shadow-lg shadow-orange-500/20">
              <BookOpenText className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h1 className="text-sm sm:text-lg font-bold tracking-tight text-white font-sans">
                  मराठी ब्लॉग विषय बुद्धिमत्ता
                </h1>
                <span className="hidden sm:inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                  Human-Centric Blog Finder
                </span>
              </div>
              <p className="text-[11px] sm:text-xs text-slate-400 hidden xs:block">
                Reader-First Blog Opportunity Finder & Content Strategist
              </p>
            </div>
          </div>

          {/* Quick Header Search Bar */}
          <div className="flex-1 max-w-xs sm:max-w-sm lg:max-w-md mx-2">
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 transform -translate-y-1/2" />
              <input
                type="text"
                placeholder="शीर्षक, मराठी शब्द किंवा कीवर्ड शोधा..."
                value={searchQuery}
                onChange={(e) => onSearchChange?.(e.target.value)}
                className="w-full bg-slate-800/90 border border-slate-700/80 text-white placeholder-slate-400 rounded-xl pl-9 pr-8 py-1.5 text-xs focus:border-amber-500 focus:bg-slate-950 focus:outline-none transition-all shadow-inner"
              />
              {searchQuery && (
                <button
                  onClick={() => onSearchChange?.('')}
                  className="absolute right-2.5 top-1/2 transform -translate-y-1/2 text-slate-400 hover:text-slate-200"
                  title="शोध पुसा (Clear)"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>

          {/* KPI Summary Pills */}
          <div className="hidden xl:flex items-center space-x-2.5 text-xs shrink-0">
            <div className="bg-slate-800/80 border border-slate-700/60 rounded-full px-3 py-1 flex items-center space-x-1.5">
              <Layers className="w-3.5 h-3.5 text-blue-400" />
              <span className="text-slate-400">एकूण:</span>
              <span className="font-bold text-blue-300">{totalCount}</span>
            </div>

            <div className="bg-slate-800/80 border border-slate-700/60 rounded-full px-3 py-1 flex items-center space-x-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              <span className="text-slate-400">स्वीकृत:</span>
              <span className="font-bold text-emerald-300">{approvedCount}</span>
            </div>

            <div className="bg-slate-800/80 border border-slate-700/60 rounded-full px-3 py-1 flex items-center space-x-1.5">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span className="text-slate-400">संशोधित:</span>
              <span className="font-bold text-amber-300">{researchBackedCount}</span>
            </div>

            {/* DB Status */}
            <div className="bg-slate-800/80 border border-slate-700/60 rounded-full px-3 py-1 flex items-center space-x-1.5">
              <Database className={`w-3.5 h-3.5 ${dbStatus ? 'text-emerald-400' : 'text-amber-400'}`} />
              <span className="text-slate-300 font-medium">IndexedDB</span>
            </div>
          </div>

          {/* Quick Action Button */}
          <div className="shrink-0">
            <button
              onClick={() => setActiveTab('generate')}
              className="inline-flex items-center space-x-1.5 bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white font-medium text-xs sm:text-sm px-3 py-1.5 sm:px-3.5 sm:py-2 rounded-lg shadow-md hover:shadow-lg transition-all"
            >
              <Sparkles className="w-4 h-4" />
              <span className="hidden sm:inline">१०० ब्लॉग विषय जनरेट करा</span>
              <span className="sm:hidden">जनरेट</span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
