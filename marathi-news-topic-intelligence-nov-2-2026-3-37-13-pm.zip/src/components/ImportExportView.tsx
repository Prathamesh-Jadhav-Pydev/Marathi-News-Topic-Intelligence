import React, { useState } from 'react';
import {
  Upload,
  Download,
  FileSpreadsheet,
  FileCode,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  Database,
  Layers,
  FileText
} from 'lucide-react';
import { TopicRecord, ImportedRecord } from '../types';
import {
  parseImportFile,
  ColumnMapping,
  exportTopicsToCSV,
  exportTopicsToJSON,
  exportSourcesToCSV
} from '../services/exportImport';
import { topicDB } from '../services/db';

interface ImportExportViewProps {
  topics: TopicRecord[];
  onImportCompleted: (importedRecords: ImportedRecord[]) => void;
}

export const ImportExportView: React.FC<ImportExportViewProps> = ({
  topics,
  onImportCompleted,
}) => {
  // Import State
  const [importFile, setImportFile] = useState<File | null>(null);
  const [fileContent, setFileContent] = useState<string>('');
  const [isJson, setIsJson] = useState<boolean>(false);
  const [parsedHeaders, setParsedHeaders] = useState<string[]>([]);
  const [mapping, setMapping] = useState<ColumnMapping>({
    headlineField: 'headline',
    urlField: 'url',
    categoryField: 'category',
    subcategoryField: 'subcategory',
    pubDateField: 'publication_date',
    keywordField: 'primary_keyword',
    contentField: 'article_content',
    statusField: 'status',
  });

  const [previewRecords, setPreviewRecords] = useState<ImportedRecord[]>([]);
  const [importErrors, setImportErrors] = useState<{ row: number; error: string }[]>([]);
  const [importSuccessMsg, setImportSuccessMsg] = useState<string | null>(null);

  // Export State
  const [exportScope, setExportScope] = useState<'all' | 'approved' | 'sources'>('all');
  const [exportFormat, setExportFormat] = useState<'csv' | 'json'>('csv');

  // Handle File Selection
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setImportFile(file);
    const jsonCheck = file.name.endsWith('.json');
    setIsJson(jsonCheck);

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      setFileContent(content);

      if (jsonCheck) {
        try {
          const parsed = JSON.parse(content);
          const firstObj = Array.isArray(parsed) ? parsed[0] : parsed;
          if (firstObj) {
            setParsedHeaders(Object.keys(firstObj));
          }
        } catch {
          setParsedHeaders([]);
        }
      } else {
        // CSV first line header extraction
        const lines = content.split('\n');
        if (lines.length > 0) {
          const headers = lines[0].split(',').map(h => h.trim().replace(/^["']|["']$/g, ''));
          setParsedHeaders(headers);

          // Auto-guess column mappings
          const findCol = (terms: string[]) => headers.find(h => terms.some(t => h.toLowerCase().includes(t))) || headers[0] || '';
          setMapping({
            headlineField: findCol(['headline', 'title', 'शीर्षक']),
            urlField: findCol(['url', 'link', 'युआरएल']),
            categoryField: findCol(['category', 'श्रेणी']),
            subcategoryField: findCol(['subcategory', 'सब']),
            pubDateField: findCol(['date', 'publication', 'तारीख']),
            keywordField: findCol(['keyword', 'कीवर्ड']),
            contentField: findCol(['content', 'summary', 'मजकूर']),
            statusField: findCol(['status', 'स्थिती']),
          });
        }
      }
    };
    reader.readAsText(file, 'UTF-8');
  };

  // Run Preview Parsing
  const handlePreviewParse = () => {
    if (!fileContent) return;
    const result = parseImportFile(fileContent, isJson, mapping);
    setPreviewRecords(result.records);
    setImportErrors(result.errors);
  };

  // Commit Import to IndexedDB
  const handleCommitImport = async () => {
    if (previewRecords.length === 0) return;
    await topicDB.saveImportedRecords(previewRecords);
    onImportCompleted(previewRecords);
    setImportSuccessMsg(`🎉 ${previewRecords.length} प्रकाशित/जुने लेख यशस्वीरीत्या डेटाबेसमध्ये समाविष्ट केले!`);
    setPreviewRecords([]);
    setImportFile(null);
  };

  // Handle Export Trigger
  const handleExport = () => {
    if (exportScope === 'sources') {
      exportSourcesToCSV(topics, 'marathi_news_sources.csv');
      return;
    }

    const exportList = exportScope === 'approved' ? topics.filter(t => t.workflow_status === 'approved') : topics;

    if (exportFormat === 'csv') {
      exportTopicsToCSV(exportList, 'marathi_news_topics.csv');
    } else {
      exportTopicsToJSON(exportList, 'marathi_news_topics.json');
    }
  };

  return (
    <div className="space-y-6">
      {/* Import Section */}
      <div className="bg-slate-800/90 border border-slate-700/80 rounded-2xl p-6 shadow-xl space-y-5">
        <div className="flex items-center space-x-2 border-b border-slate-700/60 pb-3">
          <Upload className="w-5 h-5 text-amber-400" />
          <h2 className="text-lg font-bold text-white">
            जुने लेख व शीर्षके इम्पोर्ट करा (Import Existing Headlines)
          </h2>
        </div>

        <p className="text-xs text-slate-300">
          तुमच्या वर्तमान पोर्टलवरील जुनी प्रकाशित शीर्षके CSV किंवा JSON द्वारे इम्पोर्ट करा. यामुळे ड्युप्लिकेट डिटेक्शन इंजिन नवीन सूचवलेल्या विषयांमध्ये या शीर्षकांचा पुनरुच्चार रोखेल.
        </p>

        {/* File Dropzone */}
        <div className="border-2 border-dashed border-slate-700 hover:border-amber-500/60 rounded-xl p-6 text-center bg-slate-900/50 transition-colors">
          <input
            type="file"
            accept=".csv,.json"
            onChange={handleFileChange}
            className="hidden"
            id="csv-file-input"
          />
          <label htmlFor="csv-file-input" className="cursor-pointer space-y-2 block">
            <FileSpreadsheet className="w-8 h-8 text-amber-400 mx-auto" />
            <div className="text-xs font-bold text-slate-200">
              {importFile ? importFile.name : 'CSV किंवा JSON फाईल निवडा (Click to Browse)'}
            </div>
            <div className="text-[10px] text-slate-400">UTF-8 एन्कोडेड मराठी टेक्स्ट समर्थित</div>
          </label>
        </div>

        {/* Column Mapping UI */}
        {parsedHeaders.length > 0 && (
          <div className="bg-slate-900/80 p-4 rounded-xl border border-slate-800 space-y-3">
            <h3 className="text-xs font-bold text-amber-400">कॉलम मॅपिंग (Column Mapping):</h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
              <div>
                <label className="block text-slate-400 text-[10px] mb-1">शीर्षक (Headline)*</label>
                <select
                  value={mapping.headlineField}
                  onChange={(e) => setMapping({ ...mapping, headlineField: e.target.value })}
                  className="w-full bg-slate-800 border border-slate-700 text-white rounded px-2 py-1 text-xs"
                >
                  {parsedHeaders.map(h => <option key={h} value={h}>{h}</option>)}
                </select>
              </div>

              <div>
                <label className="block text-slate-400 text-[10px] mb-1">युआरएल (URL)</label>
                <select
                  value={mapping.urlField}
                  onChange={(e) => setMapping({ ...mapping, urlField: e.target.value })}
                  className="w-full bg-slate-800 border border-slate-700 text-white rounded px-2 py-1 text-xs"
                >
                  {parsedHeaders.map(h => <option key={h} value={h}>{h}</option>)}
                </select>
              </div>

              <div>
                <label className="block text-slate-400 text-[10px] mb-1">कीवर्ड (Primary Keyword)</label>
                <select
                  value={mapping.keywordField}
                  onChange={(e) => setMapping({ ...mapping, keywordField: e.target.value })}
                  className="w-full bg-slate-800 border border-slate-700 text-white rounded px-2 py-1 text-xs"
                >
                  {parsedHeaders.map(h => <option key={h} value={h}>{h}</option>)}
                </select>
              </div>

              <div>
                <label className="block text-slate-400 text-[10px] mb-1">श्रेणी (Category)</label>
                <select
                  value={mapping.categoryField}
                  onChange={(e) => setMapping({ ...mapping, categoryField: e.target.value })}
                  className="w-full bg-slate-800 border border-slate-700 text-white rounded px-2 py-1 text-xs"
                >
                  {parsedHeaders.map(h => <option key={h} value={h}>{h}</option>)}
                </select>
              </div>
            </div>

            <button
              onClick={handlePreviewParse}
              className="bg-slate-700 hover:bg-slate-600 text-white font-bold px-4 py-2 rounded-lg text-xs"
            >
              पूर्वावलोकन पार्स करा (Preview Parse)
            </button>
          </div>
        )}

        {/* Preview Records Table */}
        {previewRecords.length > 0 && (
          <div className="space-y-3">
            <div className="flex justify-between items-center text-xs font-bold text-amber-400">
              <span>पार्स केलेल्या ५ प्रात्यक्षिक नोंदी ({previewRecords.length} पैकी):</span>
              <button
                onClick={handleCommitImport}
                className="bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold px-4 py-2 rounded-lg"
              >
                इम्पोर्ट कन्फर्म करा ({previewRecords.length} नोंदी)
              </button>
            </div>

            <div className="bg-slate-950 rounded-xl border border-slate-800 overflow-x-auto p-3 max-h-48">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="text-slate-400 border-b border-slate-800">
                    <th className="py-1 px-2">शीर्षक</th>
                    <th className="py-1 px-2">युआरएल</th>
                    <th className="py-1 px-2">कीवर्ड</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800 text-slate-300">
                  {previewRecords.slice(0, 5).map((r, i) => (
                    <tr key={i}>
                      <td className="py-1.5 px-2 font-bold">{r.headline}</td>
                      <td className="py-1.5 px-2 text-slate-400 truncate max-w-[200px]">{r.url || '—'}</td>
                      <td className="py-1.5 px-2">{r.primary_keyword || '—'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {importSuccessMsg && (
          <div className="bg-emerald-950/40 border border-emerald-800/80 rounded-xl p-3 text-xs text-emerald-300 font-bold">
            {importSuccessMsg}
          </div>
        )}
      </div>

      {/* Export Section */}
      <div className="bg-slate-800/90 border border-slate-700/80 rounded-2xl p-6 shadow-xl space-y-5">
        <div className="flex items-center space-x-2 border-b border-slate-700/60 pb-3">
          <Download className="w-5 h-5 text-amber-400" />
          <h2 className="text-lg font-bold text-white">
            डेटाबेस एक्सपोर्ट करा (Export Topic Data)
          </h2>
        </div>

        <p className="text-xs text-slate-300">
          जनरेट केलेले विषय, वृत्त ब्रिफ्स, SEO कीवर्ड्स आणि संशोधन संदर्भ एक्सेल किंवा स्प्रेडशीट सॉफ्टवेअरमध्ये वापरण्यासाठी UTF-8 BOM सह एक्सपोर्ट करा.
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
          <div>
            <label className="block text-slate-300 font-medium mb-1">एक्सपोर्ट व्याप्ती (Export Scope)</label>
            <select
              value={exportScope}
              onChange={(e) => setExportScope(e.target.value as any)}
              className="w-full bg-slate-900 border border-slate-700 text-white rounded-lg px-3 py-2"
            >
              <option value="all">सर्व {topics.length} विषय</option>
              <option value="approved">केवळ स्वीकृत विषय ({topics.filter(t => t.workflow_status === 'approved').length})</option>
              <option value="sources">केवळ संशोधन स्रोत अहवाल (Research Citations)</option>
            </select>
          </div>

          <div>
            <label className="block text-slate-300 font-medium mb-1">फाईल फॉरमॅट (File Format)</label>
            <select
              value={exportFormat}
              onChange={(e) => setExportFormat(e.target.value as any)}
              className="w-full bg-slate-900 border border-slate-700 text-white rounded-lg px-3 py-2"
            >
              <option value="csv">CSV (UTF-8 BOM Excel सुसंगत)</option>
              <option value="json">JSON (पूर्ण नेस्टेड डेटा स्ट्रक्चर)</option>
            </select>
          </div>
        </div>

        <div>
          <button
            onClick={handleExport}
            className="bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white font-bold px-6 py-3 rounded-xl shadow-lg shadow-orange-500/20 text-xs flex items-center space-x-2"
          >
            <Download className="w-4 h-4" />
            <span>फाईल डाऊनलोड करा ({exportFormat.toUpperCase()})</span>
          </button>
        </div>
      </div>
    </div>
  );
};
