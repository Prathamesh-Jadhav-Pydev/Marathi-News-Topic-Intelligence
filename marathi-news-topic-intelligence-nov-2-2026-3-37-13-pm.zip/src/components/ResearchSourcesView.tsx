import React, { useState, useMemo } from 'react';
import {
  Search,
  ExternalLink,
  ShieldCheck,
  AlertTriangle,
  Download,
  CheckCircle2,
  Globe,
  RefreshCw
} from 'lucide-react';
import { TopicRecord, SourceCitation, ResearchStatus } from '../types';
import { exportSourcesToCSV } from '../services/exportImport';
import { safeFetchJson } from '../utils/apiClient';

interface ResearchSourcesViewProps {
  topics: TopicRecord[];
  onSelectTopic: (topic: TopicRecord) => void;
}

interface FlatSourceItem extends SourceCitation {
  topicHeadline: string;
  topicId: string;
  topicCategory: string;
}

export const ResearchSourcesView: React.FC<ResearchSourcesViewProps> = ({
  topics,
  onSelectTopic,
}) => {
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [verifyingUrl, setVerifyingUrl] = useState<string | null>(null);
  const [urlVerificationResults, setUrlVerificationResults] = useState<Record<string, string>>({});

  // Flatten all sources from topic records
  const allSources: FlatSourceItem[] = useMemo(() => {
    const list: FlatSourceItem[] = [];
    topics.forEach((t) => {
      if (t.sources && Array.isArray(t.sources)) {
        t.sources.forEach((src) => {
          list.push({
            ...src,
            topicHeadline: t.primary_headline,
            topicId: t.topic_id,
            topicCategory: t.primary_category,
          });
        });
      }
    });
    return list;
  }, [topics]);

  // Filtered sources
  const filteredSources = useMemo(() => {
    return allSources.filter((src) => {
      if (searchQuery) {
        const q = searchQuery.toLowerCase();
        const titleMatch = (src.title || '').toLowerCase().includes(q);
        const urlMatch = (src.url || '').toLowerCase().includes(q);
        const claimMatch = (src.claimSupported || '').toLowerCase().includes(q);
        const headlineMatch = (src.topicHeadline || '').toLowerCase().includes(q);

        if (!titleMatch && !urlMatch && !claimMatch && !headlineMatch) return false;
      }

      if (statusFilter !== 'all' && src.verificationStatus !== statusFilter) {
        return false;
      }

      return true;
    });
  }, [allSources, searchQuery, statusFilter]);

  // Verify URL via server endpoint
  const handleVerifyUrl = async (url: string) => {
    setVerifyingUrl(url);
    try {
      const data = await safeFetchJson<{ valid?: boolean; status?: number; error?: string }>('/api/verify-url', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url }),
      });

      if (data.valid) {
        setUrlVerificationResults(prev => ({ ...prev, [url]: `✅ Valid (HTTP ${data.status})` }));
      } else {
        setUrlVerificationResults(prev => ({ ...prev, [url]: `❌ ${data.error || 'Failed'}` }));
      }
    } catch (err: any) {
      setUrlVerificationResults(prev => ({ ...prev, [url]: `❌ ${err.message || 'Network Error'}` }));
    } finally {
      setVerifyingUrl(null);
    }
  };

  return (
    <div className="space-y-4">
      {/* Search & Export Header */}
      <div className="bg-slate-800/90 border border-slate-700/80 rounded-2xl p-4 shadow-lg flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="relative w-full sm:w-96">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 transform -translate-y-1/2" />
          <input
            type="text"
            placeholder="स्रोत, दावा किंवा विषयात शोधा (Search sources, claims...)"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-900 border border-slate-700 text-white rounded-xl pl-9 pr-4 py-2 text-xs focus:border-amber-500 focus:outline-none"
          />
        </div>

        <div className="flex items-center space-x-3 text-xs w-full sm:w-auto justify-end">
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="bg-slate-900 border border-slate-700 text-slate-200 rounded-lg px-3 py-2 focus:border-amber-500 focus:outline-none"
          >
            <option value="all">सर्व संशोधन स्थिती ({allSources.length})</option>
            <option value="verified">✅ पडताळलेले (Verified)</option>
            <option value="partially_verified">⚠️ आंशिक (Partially Verified)</option>
            <option value="needs_verification">🔍 पडताळणी प्रलंबित</option>
          </select>

          <button
            onClick={() => exportSourcesToCSV(topics)}
            className="bg-slate-700 hover:bg-slate-600 text-white font-bold px-3 py-2 rounded-lg flex items-center space-x-1 shrink-0"
          >
            <Download className="w-3.5 h-3.5" />
            <span>स्रोत CSV एक्सपोर्ट</span>
          </button>
        </div>
      </div>

      {/* Sources Table */}
      <div className="bg-slate-800/90 border border-slate-700/80 rounded-2xl shadow-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-900/90 text-slate-300 text-[11px] font-bold border-b border-slate-700/80">
                <th className="py-3 px-4">स्रोत नाव व डोमेन (Source & Domain)</th>
                <th className="py-3 px-4">समर्थित दावा (Supported Claim)</th>
                <th className="py-3 px-3">संबंधित बातमी विषय (Topic)</th>
                <th className="py-3 px-3">तारीख</th>
                <th className="py-3 px-3">स्थिती</th>
                <th className="py-3 px-3 text-right">पडताळणी</th>
              </tr>
            </thead>

            <tbody className="divide-y divide-slate-700/60 text-xs">
              {filteredSources.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-slate-400">
                    <p className="font-semibold">कोणतेही संदर्भ स्रोत उपलब्ध नाहीत.</p>
                  </td>
                </tr>
              ) : (
                filteredSources.map((src, idx) => {
                  const topicObj = topics.find(t => t.topic_id === src.topicId);

                  return (
                    <tr key={`${src.id}-${idx}`} className="hover:bg-slate-700/40 transition-colors">
                      {/* Source Title & Domain */}
                      <td className="py-3.5 px-4 min-w-[220px]">
                        <div className="font-bold text-white text-xs leading-snug">{src.title}</div>
                        <div className="flex items-center space-x-2 mt-1">
                          <span className="text-[10px] text-amber-400 font-mono">{src.publisherDomain || 'Web'}</span>
                          <a
                            href={src.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-slate-400 hover:text-white flex items-center space-x-0.5 text-[10px]"
                          >
                            <span>URL</span>
                            <ExternalLink className="w-3 h-3" />
                          </a>
                        </div>
                      </td>

                      {/* Supported Claim */}
                      <td className="py-3.5 px-4 text-slate-300 max-w-[280px]">
                        <div className="line-clamp-2 leading-relaxed bg-slate-950/50 p-2 rounded border border-slate-800">
                          {src.claimSupported}
                        </div>
                      </td>

                      {/* Associated Topic Headline */}
                      <td
                        className="py-3.5 px-3 max-w-[200px] cursor-pointer hover:text-amber-300"
                        onClick={() => topicObj && onSelectTopic(topicObj)}
                      >
                        <div className="line-clamp-2 font-medium text-slate-200">
                          {src.topicHeadline}
                        </div>
                      </td>

                      {/* Dates */}
                      <td className="py-3.5 px-3 text-[11px] text-slate-400">
                        <div>प्रसिद्ध: {src.publicationDate || '—'}</div>
                        <div className="text-[10px] text-slate-500">अॅक्सेस: {src.accessDate}</div>
                      </td>

                      {/* Verification Badge */}
                      <td className="py-3.5 px-3">
                        <span className={`inline-flex items-center space-x-1 px-2 py-0.5 rounded text-[10px] font-bold ${
                          src.verificationStatus === 'verified'
                            ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                            : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                        }`}>
                          {src.verificationStatus === 'verified' ? '✅ सत्यापित' : '🔍 प्रलंबित'}
                        </span>
                      </td>

                      {/* Live Verification Trigger */}
                      <td className="py-3.5 px-3 text-right">
                        <button
                          onClick={() => handleVerifyUrl(src.url)}
                          disabled={verifyingUrl === src.url}
                          className="p-1.5 bg-slate-700 hover:bg-slate-600 text-slate-200 text-[10px] font-bold rounded-lg transition-colors flex items-center space-x-1 ml-auto"
                        >
                          <RefreshCw className={`w-3 h-3 ${verifyingUrl === src.url ? 'animate-spin' : ''}`} />
                          <span>चेक करा</span>
                        </button>

                        {urlVerificationResults[src.url] && (
                          <div className="text-[10px] font-bold mt-1 text-right">
                            {urlVerificationResults[src.url]}
                          </div>
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
