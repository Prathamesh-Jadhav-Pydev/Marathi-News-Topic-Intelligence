import React from 'react';
import {
  LayoutDashboard,
  Sparkles,
  BookOpen,
  Search,
  FileSpreadsheet,
  FolderTree,
  CheckCircle2,
  AlertTriangle
} from 'lucide-react';

interface SidebarNavProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  pendingReviewCount: number;
  duplicateCount: number;
}

export const SidebarNav: React.FC<SidebarNavProps> = ({
  activeTab,
  setActiveTab,
  pendingReviewCount,
  duplicateCount,
}) => {
  const navItems = [
    {
      id: 'dashboard',
      label: 'डॅशबोर्ड',
      sublabel: 'Dashboard Overview',
      icon: LayoutDashboard,
    },
    {
      id: 'generate',
      label: 'ब्लॉग विषय जनरेटर (१००)',
      sublabel: 'Human-Centric Blog Batch',
      icon: Sparkles,
      highlight: true,
    },
    {
      id: 'library',
      label: 'ब्लॉग ग्रंथालय',
      sublabel: 'Blog Library & Briefs',
      icon: BookOpen,
      badge: pendingReviewCount > 0 ? pendingReviewCount : undefined,
      badgeColor: 'bg-amber-500 text-white',
    },
    {
      id: 'sources',
      label: 'संशोधन स्रोत',
      sublabel: 'Reader Research Citations',
      icon: Search,
    },
    {
      id: 'import-export',
      label: 'इम्पोर्ट आणि एक्स्पोर्ट',
      sublabel: 'CSV/JSON Data Tools',
      icon: FileSpreadsheet,
    },
    {
      id: 'categories',
      label: '३० श्रेणी व सब-कॅटेगरी',
      sublabel: 'Category Taxonomy',
      icon: FolderTree,
    },
  ];

  return (
    <aside className="w-full md:w-64 bg-slate-900 border-r border-slate-800 shrink-0 p-3 flex flex-col justify-between">
      <div className="space-y-1">
        <div className="px-3 py-2 text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
          ब्लॉग मेनू (Blog Menu)
        </div>

        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;

          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full text-left px-3 py-2.5 rounded-lg flex items-center justify-between transition-all ${
                isActive
                  ? 'bg-amber-500/15 text-amber-400 border border-amber-500/30 font-medium'
                  : 'text-slate-300 hover:bg-slate-800 hover:text-white'
              } ${item.highlight && !isActive ? 'bg-gradient-to-r from-amber-500/10 to-orange-500/10 border border-amber-500/20 text-amber-300' : ''}`}
            >
              <div className="flex items-center space-x-3 min-w-0">
                <Icon
                  className={`w-5 h-5 shrink-0 ${
                    isActive
                      ? 'text-amber-400'
                      : item.highlight
                      ? 'text-amber-400'
                      : 'text-slate-400'
                  }`}
                />
                <div className="truncate">
                  <div className="text-sm font-medium leading-tight truncate">{item.label}</div>
                  <div className="text-[10px] text-slate-400 truncate">{item.sublabel}</div>
                </div>
              </div>

              {item.badge !== undefined && (
                <span
                  className={`px-2 py-0.5 rounded-full text-[10px] font-bold shrink-0 ${
                    item.badgeColor || 'bg-slate-700 text-slate-200'
                  }`}
                >
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Quick Status Notice */}
      <div className="mt-6 pt-4 border-t border-slate-800/80 px-2 text-xs text-slate-400 space-y-2">
        <div className="flex items-center justify-between text-[11px]">
          <span className="flex items-center space-x-1">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
            <span>इंजिन स्थिती:</span>
          </span>
          <span className="text-emerald-400 font-semibold">रेडी (Ready)</span>
        </div>

        {duplicateCount > 0 && (
          <div className="flex items-center justify-between text-[11px] bg-amber-950/30 border border-amber-800/40 rounded p-1.5 text-amber-300">
            <span className="flex items-center space-x-1">
              <AlertTriangle className="w-3.5 h-3.5 text-amber-400 shrink-0" />
              <span>समान विषय:</span>
            </span>
            <span className="font-bold">{duplicateCount}</span>
          </div>
        )}
      </div>
    </aside>
  );
};
