import React, { useState } from 'react';
import {
  X,
  FileText,
  Search,
  BookOpen,
  ShieldCheck,
  ExternalLink,
  CheckCircle2,
  AlertTriangle,
  User,
  Link,
  Globe,
  Tag,
  Clock,
  Layers,
  Sparkles,
  Stethoscope,
  ListChecks
} from 'lucide-react';
import { TopicRecord, WorkflowStatus, ResearchStatus } from '../types';
import { PRIMARY_CATEGORIES } from '../constants/categories';
import { safeFetchJson } from '../utils/apiClient';

interface TopicDetailDrawerProps {
  topic: TopicRecord | null;
  onClose: () => void;
  onUpdateTopic: (updatedTopic: TopicRecord) => void;
}

export const TopicDetailDrawer: React.FC<TopicDetailDrawerProps> = ({
  topic,
  onClose,
  onUpdateTopic,
}) => {
  if (!topic) return null;

  const [activeTab, setActiveTab] = useState<'brief' | 'seo' | 'research' | 'workflow'>('brief');
  const [editorNotes, setEditorNotes] = useState<string>(topic.editor_notes || '');
  const [assignedWriter, setAssignedWriter] = useState<string>(topic.assigned_writer || '');
  const [publishedUrl, setPublishedUrl] = useState<string>(topic.published_url || '');

  const [isResearching, setIsResearching] = useState<boolean>(false);
  const [researchError, setResearchError] = useState<string | null>(null);

  const catDef = PRIMARY_CATEGORIES.find(c => c.id === topic.primary_category);

  const handleRunArticleResearch = async () => {
    setIsResearching(true);
    setResearchError(null);
    try {
      const data = await safeFetchJson<{
        sources: any[];
        summary: string;
        search_queries_used: string[];
        verified_facts: string[];
        research_status: string;
      }>('/api/research-grounding', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          query: topic.primary_headline,
          category: topic.primary_category,
        }),
      });

      const updated: TopicRecord = {
        ...topic,
        sources: data.sources || [],
        research_evidence_summary: data.summary || topic.research_evidence_summary,
        search_queries_used: data.search_queries_used || topic.search_queries_used,
        verified_facts: data.verified_facts || topic.verified_facts,
        research_status: (data.research_status as ResearchStatus) || (data.sources && data.sources.length > 0 ? 'verified' : 'needs_verification'),
        last_researched_at: new Date().toISOString(),
      };

      onUpdateTopic(updated);
    } catch (err: any) {
      setResearchError(err.message || 'गूगल शोध संशोधन अयशस्वी');
    } finally {
      setIsResearching(false);
    }
  };

  const handleSaveWorkflowChanges = () => {
    const updated: TopicRecord = {
      ...topic,
      editor_notes: editorNotes,
      assigned_writer: assignedWriter,
      published_url: publishedUrl,
      last_updated_at: new Date().toISOString(),
    };
    onUpdateTopic(updated);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-slate-950/80 backdrop-blur-sm flex justify-end">
      <div className="w-full max-w-3xl bg-slate-900 border-l border-slate-800 text-white h-full flex flex-col shadow-2xl animate-in slide-in-from-right duration-200">
        {/* Drawer Header */}
        <div className="p-5 border-b border-slate-800 bg-slate-950/60 flex items-start justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center space-x-2">
              <span className={`px-2.5 py-0.5 rounded text-xs font-bold border ${catDef?.color || 'bg-slate-800 text-slate-300'}`}>
                {catDef?.marathiLabel || topic.primary_category}
              </span>
              <span className="text-xs text-slate-400">/ {topic.subcategory}</span>
              <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                {topic.evergreen_or_trending === 'trending' ? '🔥 न्यूज' : '🌲 सदाबहार'}
              </span>

              {topic.medical_verification_required && (
                <span className="inline-flex items-center space-x-1 px-2 py-0.5 rounded bg-rose-500/20 text-rose-300 border border-rose-500/30 text-[10px] font-bold">
                  <Stethoscope className="w-3 h-3" />
                  <span>वैद्यकीय पडताळणी आवश्यक</span>
                </span>
              )}
            </div>

            <h3 className="text-lg font-black text-white leading-snug">
              {topic.primary_headline}
            </h3>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors shrink-0"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation Bar */}
        <div className="border-b border-slate-800 bg-slate-900 px-5 flex space-x-6 text-xs font-bold">
          <button
            onClick={() => setActiveTab('brief')}
            className={`py-3 border-b-2 flex items-center space-x-1.5 transition-colors ${
              activeTab === 'brief'
                ? 'border-amber-500 text-amber-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>लेख ब्रिफ व रूपरेषा</span>
          </button>

          <button
            onClick={() => setActiveTab('seo')}
            className={`py-3 border-b-2 flex items-center space-x-1.5 transition-colors ${
              activeTab === 'seo'
                ? 'border-amber-500 text-amber-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Search className="w-4 h-4" />
            <span>SEO व कीवर्ड्स</span>
          </button>

          <button
            onClick={() => setActiveTab('research')}
            className={`py-3 border-b-2 flex items-center space-x-1.5 transition-colors ${
              activeTab === 'research'
                ? 'border-amber-500 text-amber-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <ShieldCheck className="w-4 h-4" />
            <span>संशोधन व पुरावे ({topic.sources?.length || 0})</span>
          </button>

          <button
            onClick={() => setActiveTab('workflow')}
            className={`py-3 border-b-2 flex items-center space-x-1.5 transition-colors ${
              activeTab === 'workflow'
                ? 'border-amber-500 text-amber-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Clock className="w-4 h-4" />
            <span>कार्यप्रवाह व ड्युप्लिकेशन</span>
          </button>
        </div>

        {/* Drawer Scrollable Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6 text-xs">
          {/* TAB 1: EDITORIAL BRIEF & OUTLINE */}
          {activeTab === 'brief' && (
            <div className="space-y-5">
              {/* Category Mismatch Warning Banner */}
              {topic.category_mismatch_warning && (
                <div className="bg-amber-950/40 border border-amber-800/80 rounded-xl p-3.5 text-xs text-amber-200 flex items-start space-x-2">
                  <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                  <div>
                    <div className="font-bold text-amber-300">श्रेणी सुसंगतता सूचना (Category Alignment Notice)</div>
                    <div className="text-slate-300 mt-0.5">{topic.category_mismatch_warning}</div>
                  </div>
                </div>
              )}

              {/* Medical Verification Warning Banner */}
              {topic.medical_verification_required && (
                <div className="bg-rose-950/40 border border-rose-800/80 rounded-xl p-4 text-xs text-rose-200 space-y-2">
                  <div className="flex items-center space-x-2 font-bold text-rose-300">
                    <Stethoscope className="w-4 h-4" />
                    <span>आरोग्य/वैद्यकीय सुरक्षा आणि पडताळणी सूचना</span>
                  </div>
                  <p className="leading-relaxed text-slate-300">
                    {topic.medical_disclaimer || 'टीप: हा विषय आरोग्य अथवा वैद्यकीय उपचारांशी संबंधित आहे. प्रकाशनापूर्वी वैद्यकीय तज्ज्ञांकडून माहितीची शहानिशा करून घेणे बंधनकारक आहे.'}
                  </p>
                </div>
              )}

              {/* Headlines Box */}
              <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-4 space-y-3">
                <div>
                  <label className="text-[10px] text-amber-400 font-bold uppercase tracking-wider block">
                    मुख्य मराठी शीर्षक (Primary Headline)
                  </label>
                  <p className="text-sm font-black text-white mt-0.5">{topic.primary_headline}</p>
                </div>

                <div className="pt-2 border-t border-slate-800/80">
                  <label className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">
                    २ पर्यायी शीर्षके (Exactly 2 Alternate Headlines)
                  </label>
                  <ul className="mt-1 space-y-1 text-slate-300">
                    <li className="flex items-start space-x-2">
                      <span className="font-bold text-amber-400 shrink-0">१.</span>
                      <span>{topic.alternate_headlines?.[0] || 'पर्यायी शीर्षक १'}</span>
                    </li>
                    <li className="flex items-start space-x-2">
                      <span className="font-bold text-amber-400 shrink-0">२.</span>
                      <span>{topic.alternate_headlines?.[1] || 'पर्यायी शीर्षक २'}</span>
                    </li>
                  </ul>
                </div>
              </div>

              {/* Topic Summary */}
              <div>
                <h4 className="text-xs font-bold text-slate-300 mb-1">विषय सारांश (Topic Summary):</h4>
                <p className="text-slate-300 leading-relaxed bg-slate-800/60 p-3 rounded-xl border border-slate-700/60">
                  {topic.topic_summary}
                </p>
              </div>

              {/* Context & Objective */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="bg-slate-800/60 p-3 rounded-xl border border-slate-700/60">
                  <h5 className="font-bold text-slate-200 mb-1">सविस्तर लेख पार्श्वभूमी (Context):</h5>
                  <p className="text-slate-300 leading-normal">{topic.detailed_article_context}</p>
                </div>

                <div className="bg-slate-800/60 p-3 rounded-xl border border-slate-700/60">
                  <h5 className="font-bold text-slate-200 mb-1">लेखाचा मुख्य उद्देश (Objective):</h5>
                  <p className="text-slate-300 leading-normal">{topic.article_objective}</p>
                </div>
              </div>

              {/* Key Questions Array */}
              {topic.key_questions_to_answer && topic.key_questions_to_answer.length > 0 && (
                <div>
                  <h4 className="text-xs font-bold text-slate-300 mb-2">लेखात उत्तरे द्यावयाचे प्रमुख प्रश्न:</h4>
                  <ul className="space-y-1.5 pl-2">
                    {topic.key_questions_to_answer.map((q, idx) => (
                      <li key={idx} className="flex items-start space-x-2 text-slate-300">
                        <span className="w-4 h-4 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center justify-center text-[10px] shrink-0 mt-0.5">
                          {idx + 1}
                        </span>
                        <span>{q}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Suggested Outline Array */}
              {topic.suggested_article_outline && topic.suggested_article_outline.length > 0 && (
                <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-4">
                  <h4 className="text-xs font-bold text-amber-400 mb-2 flex items-center space-x-1.5">
                    <BookOpen className="w-4 h-4" />
                    <span>प्रस्तावित लेख रूपरेषा (Suggested Outline):</span>
                  </h4>
                  <ol className="space-y-2">
                    {topic.suggested_article_outline.map((item, idx) => (
                      <li key={idx} className="bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-slate-200 flex items-start space-x-2">
                        <span className="font-bold text-amber-400 shrink-0">{idx + 1}.</span>
                        <span>{item}</span>
                      </li>
                    ))}
                  </ol>
                </div>
              )}

              {/* Pre-publication Verification Checklist */}
              {topic.verification_checklist && topic.verification_checklist.length > 0 && (
                <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-4 space-y-2">
                  <h4 className="text-xs font-bold text-cyan-400 flex items-center space-x-1.5">
                    <ListChecks className="w-4 h-4" />
                    <span>प्रकाशनापूर्वीची तपासणी यादी (Pre-publication Checklist):</span>
                  </h4>
                  <ul className="space-y-1 text-slate-300 pl-2">
                    {topic.verification_checklist.map((chk, i) => (
                      <li key={i} className="flex items-start space-x-2">
                        <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400 shrink-0 mt-0.5" />
                        <span>{chk}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          )}

          {/* TAB 2: SEO & SEARCH INTENT */}
          {activeTab === 'seo' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="bg-slate-800/60 p-3 rounded-xl border border-slate-700/60">
                  <label className="text-[10px] text-slate-400 font-bold uppercase block">प्रायमरी कीवर्ड (Primary Keyword)</label>
                  <p className="text-sm font-bold text-amber-400 mt-1">{topic.primary_keyword}</p>
                </div>

                <div className="bg-slate-800/60 p-3 rounded-xl border border-slate-700/60">
                  <label className="text-[10px] text-slate-400 font-bold uppercase block">सर्च इंटेंट (Search Intent)</label>
                  <p className="text-sm font-bold text-slate-200 mt-1">{topic.search_intent_type}</p>
                </div>
              </div>

              {/* Secondary Keywords */}
              {topic.secondary_keywords && topic.secondary_keywords.length > 0 && (
                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1.5">दुय्यम कीवर्ड्स (Secondary Keywords):</label>
                  <div className="flex flex-wrap gap-1.5">
                    {topic.secondary_keywords.map((kw, i) => (
                      <span key={i} className="bg-slate-800 border border-slate-700 text-slate-200 px-2.5 py-1 rounded-lg text-xs">
                        #{kw}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* Suggested Slug */}
              <div className="bg-slate-950/80 p-3 rounded-xl border border-slate-800">
                <label className="text-[10px] text-slate-400 font-bold uppercase block">प्रस्तावित युआरएल स्लग (SEO Slug)</label>
                <code className="text-xs text-amber-300 mt-1 block font-mono">{topic.suggested_slug}</code>
              </div>

              {/* Meta Description */}
              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">मेटा डिस्क्रिप्शन (Meta Description):</label>
                <div className="bg-slate-800/60 p-3 rounded-xl border border-slate-700/60 text-slate-300 italic">
                  "{topic.suggested_meta_description}"
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: RESEARCH & SOURCES */}
          {activeTab === 'research' && (
            <div className="space-y-4">
              {/* Trigger Article Research Workflow Card */}
              <div className="bg-slate-800/90 border border-slate-700/80 p-4 rounded-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-md">
                <div>
                  <h4 className="text-xs font-bold text-white flex items-center space-x-1.5">
                    <Globe className="w-4 h-4 text-amber-400 shrink-0" />
                    <span>सखोल लेख संशोधन (Google Search Grounding Workflow)</span>
                  </h4>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    या लेखासाठी गूगल सर्च ग्राउंडिंगद्वारे थेट पुरावे, अचूक संदर्भ व स्रोत माहिती मिळवा.
                  </p>
                </div>

                <button
                  onClick={handleRunArticleResearch}
                  disabled={isResearching}
                  className="bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 disabled:opacity-50 text-slate-950 font-bold px-4 py-2 rounded-lg flex items-center space-x-2 text-xs shadow-md transition-all shrink-0"
                >
                  <Sparkles className={`w-4 h-4 text-slate-950 ${isResearching ? 'animate-spin' : ''}`} />
                  <span>{isResearching ? 'गूगल सर्च चालू आहे...' : 'गूगल सर्चद्वारे संशोधन करा'}</span>
                </button>
              </div>

              {researchError && (
                <div className="bg-rose-950/40 border border-rose-800/80 rounded-xl p-3 text-xs text-rose-300">
                  ⚠️ {researchError}
                </div>
              )}

              <div className="flex items-center justify-between bg-slate-950/80 p-3.5 rounded-xl border border-slate-800">
                <div>
                  <span className="text-[10px] text-slate-400 uppercase font-bold block">संशोधन स्थिती:</span>
                  <span className={`inline-block mt-1 font-bold ${
                    topic.research_status === 'verified' ? 'text-emerald-400' : 'text-amber-400'
                  }`}>
                    {topic.research_status === 'verified' ? '✅ पूर्णपणे सत्यापित स्रोत (Google Grounded)' : '🔍 पडताळणी आवश्यक'}
                  </span>
                </div>
                <div className="text-right">
                  <span className="text-[10px] text-slate-400 block">शेवटची तपासणी:</span>
                  <span className="text-slate-300">{topic.last_researched_at ? new Date(topic.last_researched_at).toLocaleDateString() : 'नुकतीच'}</span>
                </div>
              </div>

              {/* Search Queries Used */}
              {topic.search_queries_used && topic.search_queries_used.length > 0 && (
                <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1">
                  <label className="text-[10px] text-amber-400 font-bold uppercase block">वापरलेले शोध क्वेरी (Search Queries Used):</label>
                  <div className="flex flex-wrap gap-1.5 mt-1">
                    {topic.search_queries_used.map((q, i) => (
                      <span key={i} className="bg-slate-900 border border-slate-800 text-slate-300 px-2 py-0.5 rounded font-mono text-[11px]">
                        🔍 {q}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* Research Evidence Summary */}
              {topic.research_evidence_summary && (
                <div className="bg-slate-800/60 p-3 rounded-xl border border-slate-700/60">
                  <label className="text-xs font-bold text-slate-300 block mb-1">संशोधन पुरावे सारांश (Research Evidence):</label>
                  <p className="text-slate-300 leading-relaxed">{topic.research_evidence_summary}</p>
                </div>
              )}

              {/* Source Citations Table */}
              <div>
                <h4 className="text-xs font-bold text-slate-300 mb-2">जोडलेले संदर्भ स्रोत (Source Citations):</h4>
                {(!topic.sources || topic.sources.length === 0) ? (
                  <p className="text-slate-400 italic bg-slate-800/40 p-3 rounded-xl">कोणतेही थेट वेब स्रोत जोडलेले नाहीत.</p>
                ) : (
                  <div className="space-y-2">
                    {topic.sources.map((src) => (
                      <div key={src.id} className="bg-slate-950 border border-slate-800 rounded-xl p-3 space-y-1.5">
                        <div className="flex items-start justify-between gap-2">
                          <span className="font-bold text-white leading-snug">{src.title}</span>
                          <a
                            href={src.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-amber-400 hover:underline flex items-center space-x-1 shrink-0 text-[11px]"
                          >
                            <span>लिंक उघडा</span>
                            <ExternalLink className="w-3 h-3" />
                          </a>
                        </div>

                        <div className="text-[11px] text-slate-400 flex items-center space-x-3">
                          <span>डोमेन: <strong className="text-slate-200">{src.publisherDomain}</strong></span>
                          <span>तारीख: {src.publicationDate || 'उपलब्ध नाही'}</span>
                        </div>

                        <div className="bg-slate-900 p-2 rounded text-slate-300 text-[11px] mt-1 border border-slate-800">
                          <strong className="text-amber-400">समर्थित दावा: </strong>{src.claimSupported}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 4: WORKFLOW & DEDUPLICATION */}
          {activeTab === 'workflow' && (
            <div className="space-y-5">
              {/* Duplicate Status Box */}
              <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-4 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] text-slate-400 uppercase font-bold">ड्युप्लिकेशन स्टेटस:</span>
                  <span className={`px-2 py-0.5 rounded text-xs font-bold ${
                    topic.duplicate_status === 'unique'
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                      : 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                  }`}>
                    {topic.duplicate_status === 'unique' ? 'युनिक विषय (Unique)' : 'समान विषय (Possible Duplicate)'}
                  </span>
                </div>
              </div>

              {/* Workflow Status Dropdown & Writer Assignment */}
              <div className="space-y-4 bg-slate-800/60 p-4 rounded-xl border border-slate-700/60">
                <h4 className="text-xs font-bold text-white">संपादकीय जबाबदारी आणि स्थिती:</h4>

                <div>
                  <label className="block text-[11px] text-slate-300 mb-1">नियुक्त पत्रकार/लेखक (Assigned Writer):</label>
                  <input
                    type="text"
                    value={assignedWriter}
                    onChange={(e) => setAssignedWriter(e.target.value)}
                    placeholder="उदा. प्रियांका देशमुख, आनंद जोशी"
                    className="w-full bg-slate-900 border border-slate-700 text-white rounded-lg px-3 py-2 text-xs focus:border-amber-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-[11px] text-slate-300 mb-1">प्रकाशित युआरएल (Published URL):</label>
                  <input
                    type="text"
                    value={publishedUrl}
                    onChange={(e) => setPublishedUrl(e.target.value)}
                    placeholder="https://www.news.com/article-url"
                    className="w-full bg-slate-900 border border-slate-700 text-white rounded-lg px-3 py-2 text-xs focus:border-amber-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-[11px] text-slate-300 mb-1">संपादक टीप (Editor Notes):</label>
                  <textarea
                    rows={3}
                    value={editorNotes}
                    onChange={(e) => setEditorNotes(e.target.value)}
                    placeholder="लेखनासाठी विशेष सूचना..."
                    className="w-full bg-slate-900 border border-slate-700 text-white rounded-lg p-3 text-xs focus:border-amber-500 focus:outline-none resize-none"
                  />
                </div>

                <button
                  onClick={handleSaveWorkflowChanges}
                  className="bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold px-4 py-2 rounded-lg text-xs transition-colors"
                >
                  बदल जतन करा (Save Changes)
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
