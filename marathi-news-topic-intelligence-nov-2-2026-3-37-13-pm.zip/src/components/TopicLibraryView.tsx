import React, { useState, useMemo } from 'react';
import {
  Search,
  Filter,
  CheckCircle2,
  XCircle,
  Trash2,
  Download,
  BookOpen,
  Sparkles,
  AlertTriangle,
  Clock,
  ShieldCheck,
  ChevronLeft,
  ChevronRight,
  Eye,
  FileSpreadsheet
} from 'lucide-react';
import { TopicRecord, FilterOptions, WorkflowStatus, CategoryId } from '../types';
import { PRIMARY_CATEGORIES } from '../constants/categories';
import { exportTopicsToCSV } from '../services/exportImport';

interface TopicLibraryViewProps {
  topics: TopicRecord[];
  onSelectTopic: (topic: TopicRecord) => void;
  onUpdateTopicStatus: (topicId: string, status: WorkflowStatus) => void;
  onDeleteTopic: (topicId: string) => void;
  onBulkUpdateStatus: (topicIds: string[], status: WorkflowStatus) => void;
  onBulkDelete: (topicIds: string[]) => void;
  searchQuery?: string;
  onSearchQueryChange?: (query: string) => void;
}

export const TopicLibraryView: React.FC<TopicLibraryViewProps> = ({
  topics,
  onSelectTopic,
  onUpdateTopicStatus,
  onDeleteTopic,
  onBulkUpdateStatus,
  onBulkDelete,
  searchQuery = '',
  onSearchQueryChange,
}) => {
  // Filter state
  const [filters, setFilters] = useState<FilterOptions>({
    searchQuery: searchQuery || '',
    primaryCategory: 'all',
    subcategory: 'all',
    evergreenOrTrending: 'all',
    searchIntent: 'all',
    researchStatus: 'all',
    editorialPriority: 'all',
    timelinessLabel: 'all',
    duplicateStatus: 'all',
    workflowStatus: 'all',
    medicalVerificationOnly: false,
    dateRange: 'all',
  });

  const [selectedTopicIds, setSelectedTopicIds] = useState<string[]>([]);
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [pageSize, setPageSize] = useState<number>(20);

  // Sync searchQuery prop when updated from Header
  React.useEffect(() => {
    if (searchQuery !== undefined && searchQuery !== filters.searchQuery) {
      setFilters(prev => ({ ...prev, searchQuery }));
      setCurrentPage(1);
    }
  }, [searchQuery]);

  // Available subcategories based on chosen primary category
  const availableSubcategories = useMemo(() => {
    if (filters.primaryCategory === 'all') return [];
    const cat = PRIMARY_CATEGORIES.find(c => c.id === filters.primaryCategory);
    return cat ? cat.subcategories : [];
  }, [filters.primaryCategory]);

  // Apply full-text search and filters
  const filteredTopics = useMemo(() => {
    return topics.filter(t => {
      // Full-text search
      if (filters.searchQuery) {
        const query = filters.searchQuery.toLowerCase().trim();
        const headlineMatch = (t.primary_headline || '').toLowerCase().includes(query);
        const titleMatch = (t.topic_title || '').toLowerCase().includes(query);
        const altHeadlinesMatch = (t.alternate_headlines || []).some(h => h.toLowerCase().includes(query));
        const summaryMatch = (t.topic_summary || '').toLowerCase().includes(query);
        const keywordMatch = (t.primary_keyword || '').toLowerCase().includes(query);
        const secKeywordMatch = (t.secondary_keywords || []).some(k => k.toLowerCase().includes(query));
        const subcatMatch = (t.subcategory || '').toLowerCase().includes(query);
        const catMatch = (t.primary_category || '').toLowerCase().includes(query);
        const contextMatch = (t.detailed_article_context || '').toLowerCase().includes(query);

        if (
          !headlineMatch &&
          !titleMatch &&
          !altHeadlinesMatch &&
          !summaryMatch &&
          !keywordMatch &&
          !secKeywordMatch &&
          !subcatMatch &&
          !catMatch &&
          !contextMatch
        ) {
          return false;
        }
      }

      // Category
      if (filters.primaryCategory !== 'all' && t.primary_category !== filters.primaryCategory) {
        return false;
      }

      // Subcategory
      if (filters.subcategory !== 'all' && t.subcategory !== filters.subcategory) {
        return false;
      }

      // Evergreen or Trending
      if (filters.evergreenOrTrending !== 'all' && t.evergreen_or_trending !== filters.evergreenOrTrending) {
        return false;
      }

      // Search Intent
      if (filters.searchIntent !== 'all' && t.search_intent_type !== filters.searchIntent) {
        return false;
      }

      // Research Status
      if (filters.researchStatus !== 'all' && t.research_status !== filters.researchStatus) {
        return false;
      }

      // Priority
      if (filters.editorialPriority !== 'all' && t.editorial_priority !== filters.editorialPriority) {
        return false;
      }

      // Duplicate Status
      if (filters.duplicateStatus !== 'all' && t.duplicate_status !== filters.duplicateStatus) {
        return false;
      }

      // Workflow Status
      if (filters.workflowStatus !== 'all' && t.workflow_status !== filters.workflowStatus) {
        return false;
      }

      // Medical Verification Filter
      if (filters.medicalVerificationOnly && !t.medical_verification_required) {
        return false;
      }

      return true;
    });
  }, [topics, filters]);

  // Pagination calculation
  const totalPages = Math.ceil(filteredTopics.length / pageSize) || 1;
  const paginatedTopics = useMemo(() => {
    const startIdx = (currentPage - 1) * pageSize;
    return filteredTopics.slice(startIdx, startIdx + pageSize);
  }, [filteredTopics, currentPage, pageSize]);

  // Multi-select row handlers
  const toggleSelectAll = () => {
    if (selectedTopicIds.length === paginatedTopics.length) {
      setSelectedTopicIds([]);
    } else {
      setSelectedTopicIds(paginatedTopics.map(t => t.topic_id));
    }
  };

  const toggleSelectRow = (topicId: string) => {
    if (selectedTopicIds.includes(topicId)) {
      setSelectedTopicIds(selectedTopicIds.filter(id => id !== topicId));
    } else {
      setSelectedTopicIds([...selectedTopicIds, topicId]);
    }
  };

  const handleExportSelected = () => {
    const selectedTopics = topics.filter(t => selectedTopicIds.includes(t.topic_id));
    exportTopicsToCSV(selectedTopics.length > 0 ? selectedTopics : filteredTopics, 'marathi_news_selected_topics.csv');
  };

  return (
    <div className="space-y-4">
      {/* Search & Filters Bar */}
      <div className="bg-slate-800/90 border border-slate-700/80 rounded-2xl p-4 shadow-lg space-y-3">
        {/* Search Bar & Quick Marathi Chips */}
        <div className="flex flex-col space-y-2.5">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="relative w-full sm:w-96 lg:w-[480px]">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 transform -translate-y-1/2" />
              <input
                type="text"
                placeholder="शीर्षक, मराठी शब्द, कीवर्ड किंवा विषयात शोधा (Search headlines, keywords...)"
                value={filters.searchQuery}
                onChange={(e) => {
                  const val = e.target.value;
                  setFilters({ ...filters, searchQuery: val });
                  onSearchQueryChange?.(val);
                  setCurrentPage(1);
                }}
                className="w-full bg-slate-900 border border-slate-700 text-white rounded-xl pl-9 pr-8 py-2 text-xs focus:border-amber-500 focus:outline-none shadow-inner"
              />
              {filters.searchQuery && (
                <button
                  onClick={() => {
                    setFilters({ ...filters, searchQuery: '' });
                    onSearchQueryChange?.('');
                    setCurrentPage(1);
                  }}
                  className="absolute right-2.5 top-1/2 transform -translate-y-1/2 text-slate-400 hover:text-slate-200"
                  title="शोध पुसा (Clear Search)"
                >
                  <XCircle className="w-4 h-4" />
                </button>
              )}
            </div>

            <div className="flex items-center space-x-2 text-xs w-full sm:w-auto justify-end">
              <span className="text-slate-400">एकूण निकाल:</span>
              <span className="font-bold text-amber-400 bg-amber-500/10 px-2.5 py-1 rounded-md border border-amber-500/20">
                {filteredTopics.length} विषय
              </span>
            </div>
          </div>

          {/* Quick Marathi Search Term Chips */}
          <div className="flex flex-wrap items-center gap-1.5 pt-0.5 text-[11px]">
            <span className="text-slate-400 text-[10px] font-medium mr-1 flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-amber-400 shrink-0" />
              <span>लोकप्रिय मराठी शोध शब्द:</span>
            </span>
            {['दिवाळी', 'आरोग्य', 'पालकत्व', 'बचत', 'प्रवास', 'आयुर्वेदिक', 'हाऊ-टू', 'बजेट', 'डाएट', 'फॅशन'].map((term) => {
              const isActive = filters.searchQuery.toLowerCase() === term.toLowerCase();
              return (
                <button
                  key={term}
                  onClick={() => {
                    const nextQuery = isActive ? '' : term;
                    setFilters({ ...filters, searchQuery: nextQuery });
                    onSearchQueryChange?.(nextQuery);
                    setCurrentPage(1);
                  }}
                  className={`px-2.5 py-0.5 rounded-full text-[10px] font-medium border transition-all ${
                    isActive
                      ? 'bg-amber-500 text-slate-950 font-bold border-amber-400 shadow-sm'
                      : 'bg-slate-900/80 text-slate-300 border-slate-700/80 hover:border-amber-500/50 hover:text-amber-300'
                  }`}
                >
                  {term}
                </button>
              );
            })}
            {filters.searchQuery && (
              <button
                onClick={() => {
                  setFilters({ ...filters, searchQuery: '' });
                  onSearchQueryChange?.('');
                  setCurrentPage(1);
                }}
                className="text-[10px] text-amber-400 underline font-medium ml-1 hover:text-amber-300"
              >
                फिल्टर रिसेट करा
              </button>
            )}
          </div>
        </div>

        {/* Filter Dropdowns Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-2 text-xs pt-2 border-t border-slate-700/60">
          {/* Category Filter */}
          <div>
            <label className="block text-[10px] text-slate-400 mb-0.5">श्रेणी (Category)</label>
            <select
              value={filters.primaryCategory}
              onChange={(e) => {
                setFilters({ ...filters, primaryCategory: e.target.value, subcategory: 'all' });
                setCurrentPage(1);
              }}
              className="w-full bg-slate-900 border border-slate-700 text-slate-200 rounded-lg px-2 py-1.5 focus:border-amber-500 focus:outline-none"
            >
              <option value="all">सर्व १२ श्रेणी</option>
              {PRIMARY_CATEGORIES.map(c => (
                <option key={c.id} value={c.id}>{c.marathiLabel}</option>
              ))}
            </select>
          </div>

          {/* Subcategory Filter */}
          <div>
            <label className="block text-[10px] text-slate-400 mb-0.5">सब-कॅटेगरी</label>
            <select
              value={filters.subcategory}
              onChange={(e) => {
                setFilters({ ...filters, subcategory: e.target.value });
                setCurrentPage(1);
              }}
              disabled={filters.primaryCategory === 'all'}
              className="w-full bg-slate-900 border border-slate-700 text-slate-200 rounded-lg px-2 py-1.5 focus:border-amber-500 focus:outline-none disabled:opacity-40"
            >
              <option value="all">सर्व उप-श्रेणी</option>
              {availableSubcategories.map(sub => (
                <option key={sub} value={sub}>{sub}</option>
              ))}
            </select>
          </div>

          {/* Evergreen / Trending */}
          <div>
            <label className="block text-[10px] text-slate-400 mb-0.5">स्वरूप (Type)</label>
            <select
              value={filters.evergreenOrTrending}
              onChange={(e) => {
                setFilters({ ...filters, evergreenOrTrending: e.target.value });
                setCurrentPage(1);
              }}
              className="w-full bg-slate-900 border border-slate-700 text-slate-200 rounded-lg px-2 py-1.5 focus:border-amber-500 focus:outline-none"
            >
              <option value="all">सर्व स्वरूप</option>
              <option value="evergreen">🌲 सदाबहार (Evergreen)</option>
              <option value="trending">🔥 ट्रेंडिंग (Trending)</option>
              <option value="seasonal">🎉 सण/हंगामी (Seasonal)</option>
            </select>
          </div>

          {/* Research Status */}
          <div>
            <label className="block text-[10px] text-slate-400 mb-0.5">संशोधन स्थिती</label>
            <select
              value={filters.researchStatus}
              onChange={(e) => {
                setFilters({ ...filters, researchStatus: e.target.value });
                setCurrentPage(1);
              }}
              className="w-full bg-slate-900 border border-slate-700 text-slate-200 rounded-lg px-2 py-1.5 focus:border-amber-500 focus:outline-none"
            >
              <option value="all">सर्व संशोधन स्थिती</option>
              <option value="verified">✅ सत्यापित (Verified)</option>
              <option value="partially_verified">⚠️ आंशिक (Partially)</option>
              <option value="needs_verification">🔍 पडताळणी हवी</option>
            </select>
          </div>

          {/* Priority */}
          <div>
            <label className="block text-[10px] text-slate-400 mb-0.5">प्राधान्य क्रम (Priority)</label>
            <select
              value={filters.editorialPriority}
              onChange={(e) => {
                setFilters({ ...filters, editorialPriority: e.target.value });
                setCurrentPage(1);
              }}
              className="w-full bg-slate-900 border border-slate-700 text-slate-200 rounded-lg px-2 py-1.5 focus:border-amber-500 focus:outline-none"
            >
              <option value="all">सर्व प्राधान्य</option>
              <option value="high">उच्च प्राधान्य (High)</option>
              <option value="medium">मध्यम (Medium)</option>
              <option value="low">साधारण (Low)</option>
            </select>
          </div>

          {/* Workflow Status */}
          <div>
            <label className="block text-[10px] text-slate-400 mb-0.5">कार्यप्रवाह स्थिती</label>
            <select
              value={filters.workflowStatus}
              onChange={(e) => {
                setFilters({ ...filters, workflowStatus: e.target.value });
                setCurrentPage(1);
              }}
              className="w-full bg-slate-900 border border-slate-700 text-slate-200 rounded-lg px-2 py-1.5 focus:border-amber-500 focus:outline-none"
            >
              <option value="all">सर्व स्थिती</option>
              <option value="idea">नवीन कल्पना (Idea)</option>
              <option value="under_review">रिव्ह्यूमध्ये (Review)</option>
              <option value="approved">स्वीकृत (Approved)</option>
              <option value="assigned">सोपवले (Assigned)</option>
              <option value="published">प्रकाशित (Published)</option>
              <option value="rejected">बाद (Rejected)</option>
            </select>
          </div>
        </div>
      </div>

      {/* Bulk Action Controls */}
      {selectedTopicIds.length > 0 && (
        <div className="bg-amber-500/15 border border-amber-500/40 rounded-xl p-3 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center space-x-2 text-amber-300 font-bold">
            <CheckCircle2 className="w-4 h-4 text-amber-400" />
            <span>{selectedTopicIds.length} विषय निवडले आहेत</span>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={() => {
                onBulkUpdateStatus(selectedTopicIds, 'approved');
                setSelectedTopicIds([]);
              }}
              className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-3 py-1.5 rounded-lg flex items-center space-x-1"
            >
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>स्वीकृत करा</span>
            </button>

            <button
              onClick={handleExportSelected}
              className="bg-slate-700 hover:bg-slate-600 text-white font-bold px-3 py-1.5 rounded-lg flex items-center space-x-1"
            >
              <Download className="w-3.5 h-3.5" />
              <span>CSV एक्सपोर्ट</span>
            </button>

            <button
              onClick={() => {
                onBulkDelete(selectedTopicIds);
                setSelectedTopicIds([]);
              }}
              className="bg-rose-600 hover:bg-rose-500 text-white font-bold px-3 py-1.5 rounded-lg flex items-center space-x-1"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>हटवा (Delete)</span>
            </button>
          </div>
        </div>
      )}

      {/* Main Topic Library Table */}
      <div className="bg-slate-800/90 border border-slate-700/80 rounded-2xl shadow-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-900/90 text-slate-300 text-[11px] font-bold border-b border-slate-700/80">
                <th className="py-3 px-3 w-10 text-center">
                  <input
                    type="checkbox"
                    checked={selectedTopicIds.length === paginatedTopics.length && paginatedTopics.length > 0}
                    onChange={toggleSelectAll}
                    className="rounded bg-slate-800 border-slate-700 text-amber-500 focus:ring-0"
                  />
                </th>
                <th className="py-3 px-4">मराठी मुख्य व पर्यायी शीर्षके (Headlines)</th>
                <th className="py-3 px-3">श्रेणी / सब-कॅटेगरी</th>
                <th className="py-3 px-3">कीवर्ड व प्रकार</th>
                <th className="py-3 px-3">संशोधन</th>
                <th className="py-3 px-3">प्राधान्य</th>
                <th className="py-3 px-3">स्थिती (Status)</th>
                <th className="py-3 px-3 text-right">कृती (Action)</th>
              </tr>
            </thead>

            <tbody className="divide-y divide-slate-700/60 text-xs">
              {paginatedTopics.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-slate-400">
                    <p className="font-semibold">निवडलेल्या फिल्टर्सनुसार कोणतेही विषय सापडले नाहीत.</p>
                    <p className="text-xs text-slate-500 mt-1">फिल्टर्स क्लियर करा किंवा नवीन १०० विषयांची बॅच जनरेट करा.</p>
                  </td>
                </tr>
              ) : (
                paginatedTopics.map((topic) => {
                  const catDef = PRIMARY_CATEGORIES.find(c => c.id === topic.primary_category);
                  const isSelected = selectedTopicIds.includes(topic.topic_id);

                  return (
                    <tr
                      key={topic.topic_id}
                      onClick={() => onSelectTopic(topic)}
                      className={`hover:bg-slate-700/40 transition-colors cursor-pointer ${
                        isSelected ? 'bg-amber-500/10' : ''
                      }`}
                    >
                      {/* Checkbox */}
                      <td className="py-3.5 px-3 text-center" onClick={(e) => e.stopPropagation()}>
                        <input
                          type="checkbox"
                          checked={isSelected}
                          onChange={() => toggleSelectRow(topic.topic_id)}
                          className="rounded bg-slate-800 border-slate-700 text-amber-500 focus:ring-0"
                        />
                      </td>

                      {/* Marathi Headline + Alternate Preview */}
                      <td className="py-3.5 px-4 min-w-[280px]">
                        <div className="font-bold text-white text-sm hover:text-amber-300 transition-colors line-clamp-2 leading-snug">
                          {topic.primary_headline}
                        </div>

                        {/* Alternate Headlines Collapsible Preview */}
                        {topic.alternate_headlines && topic.alternate_headlines.length > 0 && (
                          <div className="mt-1 text-[11px] text-slate-400 space-y-0.5">
                            <span className="text-slate-500 font-semibold">पर्यायी १: </span>
                            <span className="text-slate-300">{topic.alternate_headlines[0]}</span>
                          </div>
                        )}
                      </td>

                      {/* Category Badge */}
                      <td className="py-3.5 px-3 shrink-0">
                        <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold border ${catDef?.color || 'bg-slate-800 text-slate-300'}`}>
                          {catDef?.marathiLabel || topic.primary_category}
                        </span>
                        <div className="text-[10px] text-slate-400 mt-1 truncate max-w-[120px]">
                          {topic.subcategory}
                        </div>
                        {topic.category_mismatch_warning && (
                          <div
                            className="mt-1 flex items-center space-x-1 text-[10px] text-amber-300 bg-amber-500/10 border border-amber-500/30 rounded px-1.5 py-0.5 font-medium max-w-[130px]"
                            title={topic.category_mismatch_warning}
                          >
                            <AlertTriangle className="w-3 h-3 text-amber-400 shrink-0" />
                            <span className="truncate">श्रेणी इशारा</span>
                          </div>
                        )}
                      </td>

                      {/* Keywords & Intent */}
                      <td className="py-3.5 px-3">
                        <div className="font-semibold text-slate-200 text-xs">{topic.primary_keyword}</div>
                        <div className="flex items-center space-x-1 mt-1">
                          <span className="text-[10px] px-1.5 py-0.2 rounded bg-slate-900 text-slate-400 border border-slate-700">
                            {topic.evergreen_or_trending === 'trending' ? '🔥 न्यूज' : '🌲 सदाबहार'}
                          </span>
                          <span className="text-[10px] text-slate-400">{topic.search_intent_type}</span>
                        </div>
                      </td>

                      {/* Research Status */}
                      <td className="py-3.5 px-3">
                        <span className={`inline-flex items-center space-x-1 px-2 py-0.5 rounded text-[10px] font-bold ${
                          topic.research_status === 'verified'
                            ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                            : topic.research_status === 'partially_verified'
                            ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                            : 'bg-slate-700 text-slate-300'
                        }`}>
                          {topic.research_status === 'verified' ? '✅ सत्यापित' : '🔍 पडताळणी'}
                        </span>
                        <div className="text-[10px] text-slate-400 mt-1">
                          {topic.sources?.length || 0} स्रोत जोडलेले
                        </div>
                      </td>

                      {/* Editorial Priority */}
                      <td className="py-3.5 px-3">
                        <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold ${
                          topic.editorial_priority === 'high'
                            ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                            : topic.editorial_priority === 'medium'
                            ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                            : 'bg-slate-700 text-slate-300'
                        }`}>
                          {topic.editorial_priority === 'high' ? 'उच्च' : topic.editorial_priority === 'medium' ? 'मध्यम' : 'साधारण'}
                        </span>
                      </td>

                      {/* Workflow Dropdown */}
                      <td className="py-3.5 px-3" onClick={(e) => e.stopPropagation()}>
                        <select
                          value={topic.workflow_status}
                          onChange={(e) => onUpdateTopicStatus(topic.topic_id, e.target.value as WorkflowStatus)}
                          className="bg-slate-900 border border-slate-700 text-xs text-slate-200 rounded px-2 py-1 focus:border-amber-500 focus:outline-none"
                        >
                          <option value="idea">कल्पना (Idea)</option>
                          <option value="under_review">रिव्ह्यूमध्ये</option>
                          <option value="approved">स्वीकृत (Approved)</option>
                          <option value="assigned">सोपवले (Assigned)</option>
                          <option value="published">प्रकाशित</option>
                          <option value="rejected">बाद (Rejected)</option>
                        </select>
                      </td>

                      {/* Action Buttons */}
                      <td className="py-3.5 px-3 text-right" onClick={(e) => e.stopPropagation()}>
                        <div className="flex items-center justify-end space-x-1">
                          <button
                            onClick={() => onSelectTopic(topic)}
                            className="p-1.5 text-slate-400 hover:text-amber-400 hover:bg-slate-700 rounded-lg transition-colors"
                            title="ब्रिफ व तपशील पाहा"
                          >
                            <Eye className="w-4 h-4" />
                          </button>

                          <button
                            onClick={() => onDeleteTopic(topic.topic_id)}
                            className="p-1.5 text-slate-400 hover:text-rose-400 hover:bg-slate-700 rounded-lg transition-colors"
                            title="हटवा"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination Controls */}
        <div className="bg-slate-900/90 border-t border-slate-700/80 px-4 py-3 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-400">
          <div className="flex items-center space-x-2">
            <span>प्रति पृष्ठ विषय दाखवा:</span>
            <select
              value={pageSize}
              onChange={(e) => {
                setPageSize(parseInt(e.target.value, 10));
                setCurrentPage(1);
              }}
              className="bg-slate-800 border border-slate-700 text-slate-200 rounded px-2 py-1 focus:outline-none"
            >
              <option value={10}>१०</option>
              <option value={20}>२०</option>
              <option value={50}>५०</option>
              <option value={100}>१०० (पूर्ण पृष्ठ)</option>
            </select>
          </div>

          <div className="flex items-center space-x-3">
            <span>
              पृष्ठ {currentPage} / {totalPages} ({filteredTopics.length} पैकी)
            </span>

            <div className="flex items-center space-x-1">
              <button
                onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                disabled={currentPage === 1}
                className="p-1.5 bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-200 rounded-lg transition-colors"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>

              <button
                onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                disabled={currentPage === totalPages}
                className="p-1.5 bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-200 rounded-lg transition-colors"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
