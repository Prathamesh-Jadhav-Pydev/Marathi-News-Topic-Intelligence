import { CategoryDef } from '../types';

export const PRIMARY_CATEGORIES: CategoryDef[] = [
  // --- ORIGINAL 12 CATEGORIES ---
  {
    id: 'lifestyle',
    englishLabel: 'Lifestyle',
    marathiLabel: 'जीवनशैली',
    color: 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-300 dark:border-emerald-800',
    iconName: 'Sparkles',
    description: 'दैनंदिन जीवनमान, सुजाण आयुष्य, व्यक्तिमत्त्व विकास आणि आधुनिक जीवनशैली',
    subcategories: [
      'स्वास्थ्याभ्यास व योग',
      'व्यक्तिमत्त्व विकास',
      'कौटुंबिक नातेसंबंध',
      'दैनंदिन सवयी व शिस्त',
      'आर्थिक नियोजन व बचत',
      'वर्क-लाइफ बॅलन्स'
    ]
  },
  {
    id: 'fashion',
    englishLabel: 'Fashion',
    marathiLabel: 'फॅशन',
    color: 'bg-pink-50 text-pink-700 border-pink-200 dark:bg-pink-950/40 dark:text-pink-300 dark:border-pink-800',
    iconName: 'Shirt',
    description: 'पारंपरिक महाराष्ट्रीयन फॅशन, आधुनिक ट्रेंड्स, दागिने आणि सौंदर्य सल्ला',
    subcategories: [
      'पारंपरिक पैठणी व साड्या',
      'सण-उत्सवांसाठी फॅशन',
      'दागिने व अलंकार ट्रेंड्स',
      'सौंदर्य व त्वचा काळजी',
      'बजेट फॅशन गाइड',
      'पुरुषांची एथनिक फॅशन'
    ]
  },
  {
    id: 'devotional',
    englishLabel: 'Devotional',
    marathiLabel: 'अध्यात्म आणि भक्ती',
    color: 'bg-amber-50 text-amber-800 border-amber-200 dark:bg-amber-950/40 dark:text-amber-300 dark:border-amber-800',
    iconName: 'Flame',
    description: 'व्रत-वैकल्ये, पूजाविधी, धार्मिक इतिहास, स्तोत्र-मंत्र आणि अष्टविनायक-ज्योतिर्लिंग इतिहास',
    subcategories: [
      'व्रत-वैकल्ये व कथा',
      'पूजाविधी व सोपस्कार',
      'अष्टविनायक व ज्योतिर्लिंग दर्शन',
      'संत साहित्य व विचार',
      'स्तोत्र, आरती व मंत्रशास्त्र',
      'धार्मिक सणांचे महत्त्व'
    ]
  },
  {
    id: 'women',
    englishLabel: 'Women',
    marathiLabel: 'महिला',
    color: 'bg-rose-50 text-rose-700 border-rose-200 dark:bg-rose-950/40 dark:text-rose-300 dark:border-rose-800',
    iconName: 'HeartHandshake',
    description: 'महिलांचे यश, करिअर, हक्क, कायदे, स्वयंसिद्धता आणि आर्थिक साक्षरता',
    subcategories: [
      'कर्तृत्ववान महिलांच्या यशोगाथा',
      'गृहउद्योग व महिला उद्योजकता',
      'महिला आरोग्य व फिटनेस',
      'कायदेशीर हक्क व कायदे',
      'महिला आर्थिक साक्षरता',
      'मातृत्व व कार्यक्षेत्र संतुलन'
    ]
  },
  {
    id: 'health',
    englishLabel: 'Health',
    marathiLabel: 'आरोग्य',
    color: 'bg-teal-50 text-teal-700 border-teal-200 dark:bg-teal-950/40 dark:text-teal-300 dark:border-teal-800',
    iconName: 'Activity',
    isHealthCategory: true,
    description: 'आयुर्वेदिक घरगुती उपाय, मानसिक आरोग्य, पोषण, निसर्गोपचार व वैद्यकीय मार्गदर्शक',
    subcategories: [
      'आयुर्वेदिक घरगुती उपाय',
      'मानसिक आरोग्य व ताणतणाव',
      'हंगामी आजार व काळजी',
      'आहार, पोषण व डाएट प्लॅन',
      'योगासने व प्राणायाम',
      'ज्येष्ठ नागरिकांचे आरोग्य'
    ]
  },
  {
    id: 'astrology',
    englishLabel: 'Astrology',
    marathiLabel: 'ज्योतिष',
    color: 'bg-purple-50 text-purple-700 border-purple-200 dark:bg-purple-950/40 dark:text-purple-300 dark:border-purple-800',
    iconName: 'MoonStar',
    description: 'राशीभविष्य, गृह-नक्षत्र बदल, वास्तू टिप्स, शुभ मुहूर्त आणि स्वप्नशास्त्र',
    subcategories: [
      'दैनंदिन व साप्ताहिक राशीभविष्य',
      'ग्रहगोचर व राशी परिवर्तन',
      'वास्तू टिप्स व उपाय',
      'शुभ मुहूर्त व पंचांग',
      'अंकशास्त्र व नामकरण',
      'रत्नशास्त्र व धार्मिक तोडगे'
    ]
  },
  {
    id: 'parenting',
    englishLabel: 'Parenting',
    marathiLabel: 'पालकत्व',
    color: 'bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-950/40 dark:text-blue-300 dark:border-blue-800',
    iconName: 'Baby',
    description: 'बालसंगोपन, मुलांचा अभ्यास, मानसिक विकास, स्क्रीन टाईम आणि सुजाण पालकत्व',
    subcategories: [
      'लहान मुलांचे संगोपन व आहार',
      'अभ्यासाचे नियोजन व एकाग्रता',
      'स्क्रीन टाईम व्यवस्थापन',
      'पौगंडावस्था व सुसंवाद',
      'मुलांचे मानसिक आरोग्य',
      'खेळ व अष्टपैलू विकास'
    ]
  },
  {
    id: 'food',
    englishLabel: 'Food',
    marathiLabel: 'खाद्यसंस्कृती आणि पाककृती',
    color: 'bg-orange-50 text-orange-700 border-orange-200 dark:bg-orange-950/40 dark:text-orange-300 dark:border-orange-800',
    iconName: 'Utensils',
    description: 'पारंपरिक महाराष्ट्रीयन पाककृती, सणांचे विशेष पदार्थ, स्ट्रीट फूड आणि आरोग्यदायी स्नॅक्स',
    subcategories: [
      'पारंपरिक महाराष्ट्रीयन पाककृती',
      'सण-उत्सवांचे विशेष नैवेद्य',
      'झटपट होणारे नाश्त्याचे पदार्थ',
      'कोकणी व मालवणी व्हेज/नॉन्व्हेज',
      'खानदेशी व वऱ्हाडी तिखट पाककृती',
      'कमी उष्मांक आरोग्यदायी आहार'
    ]
  },
  {
    id: 'entertainment',
    englishLabel: 'Entertainment',
    marathiLabel: 'मनोरंजन',
    color: 'bg-indigo-50 text-indigo-700 border-indigo-200 dark:bg-indigo-950/40 dark:text-indigo-300 dark:border-indigo-800',
    iconName: 'Film',
    description: 'मराठी चित्रपट, टीव्ही मालिका, नाटके, ओटीटी रिलीज, बॉक्स ऑफिस व सेलिब्रिटीज',
    subcategories: [
      'मराठी चित्रपट रिव्ह्यू व अपडेट्स',
      'टीव्ही मालिकांचा महाएपिसोड ट्विस्ट',
      'ओटीटी वेब सीरिज गाइड',
      'मराठी नाट्यसृष्टी व कलावंत',
      'सेलिब्रिटी मुलाखती व जीवनपट',
      'संगीत व गाण्यांची समीक्षा'
    ]
  },
  {
    id: 'culture_tradition',
    englishLabel: 'Culture & Tradition',
    marathiLabel: 'संस्कृती आणि परंपरा',
    color: 'bg-red-50 text-red-700 border-red-200 dark:bg-red-950/40 dark:text-red-300 dark:border-red-800',
    iconName: 'Landmark',
    description: 'महाराष्ट्राचा इतिहास, लोककला, शिवकालीन गड-किल्ले, सण-उत्सव परंपरा आणि साहित्य',
    subcategories: [
      'महाराष्ट्राची लोककला व लावणी/पोवाडा',
      'शिवकालीन गड-किल्ले इतिहास',
      'सण व उत्सव परंपरा',
      'मराठी भाषा व वाङ्मय',
      'इतिहासकालीन शूरवीर व वाडे',
      'महाराष्ट्राचे पारंपरिक खेळ'
    ]
  },
  {
    id: 'home_decor',
    englishLabel: 'Home & Decor',
    marathiLabel: 'घर आणि सजावट',
    color: 'bg-cyan-50 text-cyan-700 border-cyan-200 dark:bg-cyan-950/40 dark:text-cyan-300 dark:border-cyan-800',
    iconName: 'Home',
    description: 'गृहसजावट टिप्स, बजेट इंटीरिअर, रंगसंगती, सणांची रांगोळी-सजावट आणि इनडोअर रोपे',
    subcategories: [
      'सणांसाठी घरगुती सजावट',
      'बजेट इंटीरिअर डेकोर टिप्स',
      'वास्तू सुसंगत गृहसजावट',
      'इनडोअर रोपे व बागकाम',
      'किचन व हॉल स्पेस सेव्हिंग',
      'रांगोळी व तोरण डिझाइन्स'
    ]
  },
  {
    id: 'travel',
    englishLabel: 'Travel',
    marathiLabel: 'प्रवास आणि पर्यटन',
    color: 'bg-lime-50 text-lime-800 border-lime-200 dark:bg-lime-950/40 dark:text-lime-300 dark:border-lime-800',
    iconName: 'Compass',
    description: 'महाराष्ट्रातील निसर्गरम्य ठिकाणे, पावसाळी ट्रिप्स, गड-किल्ले ट्रेकिंग आणि धार्मिक पर्यटन',
    subcategories: [
      'महाराष्ट्रातील निसर्गरम्य पर्यटन स्थळे',
      'पावसाळी ट्रेकिंग व धबधबे',
      'कोकणातील समुद्रकिनारे व स्टे',
      'धार्मिक तीर्थक्षेत्र दर्शन गाइड',
      'बजेट फॅमिली ट्रिप प्लॅनिंग',
      'एकदिवसीय वीकेंड गेटवे'
    ]
  },

  // --- 18 ADDITIONAL CATEGORIES ---
  {
    id: 'pregnancy',
    englishLabel: 'Pregnancy',
    marathiLabel: 'गर्भधारणा',
    color: 'bg-pink-100 text-pink-800 border-pink-300 dark:bg-pink-950/60 dark:text-pink-300',
    iconName: 'Baby',
    isHealthCategory: true,
    description: 'गर्भधारणा आठवड्यानुसार, पूर्व-जन्म काळजी, पोषण, चिन्हे आणि बाळंतपणानंतरची रिकव्हरी',
    subcategories: [
      'Pregnancy week by week (आठवड्यानुसार काळजी)',
      'Prenatal care (गर्भपूर्व काळजी)',
      'Pregnancy nutrition (गरोदरपणातील आहार)',
      'Pregnancy symptoms (गर्भावस्थेची लक्षणे)',
      'Pregnancy tests (चाचण्या व सोनोग्राफी)',
      'Postpartum recovery (बाळंतपणानंतरची काळजी)'
    ]
  },
  {
    id: 'adolescence',
    englishLabel: 'Adolescence',
    marathiLabel: 'पौगंडावस्था',
    color: 'bg-indigo-100 text-indigo-800 border-indigo-300 dark:bg-indigo-950/60 dark:text-indigo-300',
    iconName: 'UserCheck',
    isHealthCategory: true,
    description: 'पौगंडावस्थेतील शारीरिक बदल, भावनिक स्वास्थ्य, पौगंड आरोग्य आणि पोषण',
    subcategories: [
      'Puberty (वयात येतानाचे बदल)',
      'Adolescent health (पौगंड आरोग्य)',
      'Emotional wellbeing (भावनिक आरोग्य)',
      'Body changes (शारीरिक बदल)',
      'Adolescent nutrition (पौगंड पोषण)'
    ]
  },
  {
    id: 'infertility',
    englishLabel: 'Infertility',
    marathiLabel: 'वंध्यत्व',
    color: 'bg-purple-100 text-purple-800 border-purple-300 dark:bg-purple-950/60 dark:text-purple-300',
    iconName: 'HeartPulse',
    isHealthCategory: true,
    description: 'प्रजनन क्षमता जागृती, चाचण्या, उपचार पद्धती (IVF), समज-गैरसमज आणि भावनिक आधार',
    subcategories: [
      'Fertility awareness (प्रजनन साक्षरता)',
      'Fertility testing (चाचण्या व तपासणी)',
      'Treatment explainers (IVF व उपचार पद्धती)',
      'Fertility myths (वंध्यत्वाबाबत गैरसमज)',
      'Emotional support (भावनिक आधार)'
    ]
  },
  {
    id: 'family_planning',
    englishLabel: 'Family Planning',
    marathiLabel: 'कुटुंब नियोजन',
    color: 'bg-teal-100 text-teal-800 border-teal-300 dark:bg-teal-950/60 dark:text-teal-300',
    iconName: 'Users',
    isHealthCategory: true,
    description: 'गर्भनिरोधक शिक्षण, मुलांमधील अंतर, प्रजननाशी संबंधित आरोग्य आणि संसाधने',
    subcategories: [
      'Contraception education (गर्भनिरोधक साधने)',
      'Birth spacing (मुलांमधील योग्य अंतर)',
      'Reproductive health (प्रजनन आरोग्य)',
      'Family planning resources (सरकारी योजना)'
    ]
  },
  {
    id: 'gynaecological_disorders',
    englishLabel: 'Gynaecological Disorders',
    marathiLabel: 'स्त्रीरोग',
    color: 'bg-rose-100 text-rose-800 border-rose-300 dark:bg-rose-950/60 dark:text-rose-300',
    iconName: 'Stethoscope',
    isHealthCategory: true,
    description: 'PCOS/PCOD, एंडोमेट्रिओसिस, फायब्रॉइड्स, लक्षणे आणि उपचारांची माहिती',
    subcategories: [
      'PCOS and PCOD (पीसीओएस व पीसीओडी)',
      'Endometriosis (एंडोमेट्रिओसिस)',
      'Fibroids (गर्भाशयातील गाठी)',
      'Common gynaecological symptoms (स्त्रीरोग लक्षणे)',
      'Diagnosis and treatment explainers (निदान व उपचार)'
    ]
  },
  {
    id: 'menopause',
    englishLabel: 'Menopause',
    marathiLabel: 'रजोनिवृत्ती',
    color: 'bg-amber-100 text-amber-800 border-amber-300 dark:bg-amber-950/60 dark:text-amber-300',
    iconName: 'Sun',
    isHealthCategory: true,
    description: 'पेरिमेनोपॉज, रजोनिवृत्तीची लक्षणे, हाडांचे आरोग्य, झोप आणि उपचार पर्याय',
    subcategories: [
      'Perimenopause (रजोनिवृत्तीपूर्व बदल)',
      'Symptoms (हॉट फ्लॅश व लक्षणे)',
      'Bone health (हाडांची काळजी व कॅल्शियम)',
      'Sleep and wellbeing (शांत झोप व मानसिक आरोग्य)',
      'Treatment options (हार्मोन थेरपी व जीवनशैली)'
    ]
  },
  {
    id: 'menstrual_cycle',
    englishLabel: 'Menstrual Cycle',
    marathiLabel: 'मासिक पाळी',
    color: 'bg-red-100 text-red-800 border-red-300 dark:bg-red-950/60 dark:text-red-300',
    iconName: 'Calendar',
    isHealthCategory: true,
    description: 'पाळीचे ट्रॅकिंग, लक्षणे, स्वच्छता, अनियमित पाळी आणि आरोग्य साक्षरता',
    subcategories: [
      'Cycle tracking (पाळीचे गणित ट्रॅक करणे)',
      'Period symptoms (क्रॅम्प्स व दुखणे)',
      'Menstrual hygiene (स्वच्छता व सॅनिटरी पॅड्स/कप्स)',
      'Irregular periods (अनियमित पाळीची कारणे)',
      'Menstrual health education (आरोग्य साक्षरता)'
    ]
  },
  {
    id: 'anaemia',
    englishLabel: 'Anaemia',
    marathiLabel: 'रक्तक्षय',
    color: 'bg-red-200 text-red-900 border-red-400 dark:bg-red-950/80 dark:text-red-200',
    iconName: 'Droplet',
    isHealthCategory: true,
    description: 'लोहाची कमतरता, आहारातील लोहस्रोत, लक्षणे, निदान आणि प्रतिबंध उपाय',
    subcategories: [
      'Iron deficiency (लोहाची कमतरता)',
      'Nutrition and dietary sources (लोहयुक्त आहार)',
      'Symptoms and diagnosis (लक्षणे व हिमोग्लोबिन तपासणी)',
      'Prevention and treatment explainers (प्रतिबंध व गोळ्या)'
    ]
  },
  {
    id: 'fitness',
    englishLabel: 'Fitness',
    marathiLabel: 'फिटनेस',
    color: 'bg-emerald-100 text-emerald-800 border-emerald-300 dark:bg-emerald-950/60 dark:text-emerald-300',
    iconName: 'Dumbbell',
    description: 'व्यायाम दिनचर्या, स्ट्रेंथ ट्रेनिंग, चालणे, योगासने आणि नवशिक्यांसाठी फिटनेस',
    subcategories: [
      'Exercise routines (व्यायाम दिनचर्या)',
      'Strength training (स्ट्रेंथ व वेट ट्रेनिंग)',
      'Walking and yoga (चालणे व योगासने)',
      'Fitness for beginners (नवशिक्यांसाठी सोपे व्यायाम)',
      'Recovery and mobility (फ्लॅक्सिबिलिटी व विश्रांती)'
    ]
  },
  {
    id: 'weight_loss_diet',
    englishLabel: 'Weight Loss & Diet',
    marathiLabel: 'वजन कमी करणे आणि आहार',
    color: 'bg-lime-100 text-lime-800 border-lime-300 dark:bg-lime-950/60 dark:text-lime-300',
    iconName: 'Scale',
    isHealthCategory: true,
    description: 'संतुलित आहार, पोषण, शाश्वत वजन नियंत्रण, मील प्लॅनिंग आणि डाएटचे गैरसमज',
    subcategories: [
      'Balanced diet (संतुलित भारतीय आहार)',
      'Nutrition explainers (प्रोटीन व कॅलरीज)',
      'Sustainable weight management (शाश्वत वजन नियंत्रण)',
      'Meal planning (आहाराचे आठवडा प्लॅनिंग)',
      'Diet myths (डाएटबाबत समज-गैरसमज)'
    ]
  },
  {
    id: 'beauty',
    englishLabel: 'Beauty',
    marathiLabel: 'सौंदर्य',
    color: 'bg-fuchsia-100 text-fuchsia-800 border-fuchsia-300 dark:bg-fuchsia-950/60 dark:text-fuchsia-300',
    iconName: 'Sparkles',
    description: 'त्वचा काळजी, केसांची काळजी, मेक-अप, घरगुती घटक आणि सौंदर्य उत्पादनांची माहिती',
    subcategories: [
      'Skincare (त्वचेची काळजी)',
      'Haircare (केसांचे आरोग्य व तेल)',
      'Makeup (मेकअप गाइड)',
      'Beauty ingredients (हळद, कोरफड घरगुती घटक)',
      'Beauty product explainers (उत्पादने कशी वापरावीत)'
    ]
  },
  {
    id: 'shopping',
    englishLabel: 'Shopping',
    marathiLabel: 'खरेदी',
    color: 'bg-blue-100 text-blue-800 border-blue-300 dark:bg-blue-950/60 dark:text-blue-300',
    iconName: 'ShoppingBag',
    description: 'खरेदी मार्गदर्शक, वस्तूंची तुलना, बजेट शॉपिंग, सणांची खरेदी आणि ग्राहक जागृती',
    subcategories: [
      'Buying guides (खरेदी मार्गदर्शक)',
      'Product comparisons (उत्पादनांची तुलना)',
      'Budget shopping (बजेट शॉपिंग टिप्स)',
      'Seasonal shopping (सण-उत्सव खरेदी)',
      'Consumer awareness (ग्राहक हक्क व फसवणूक)'
    ]
  },
  {
    id: 'relationships_sexual_health',
    englishLabel: 'Relationships & Sexual Health',
    marathiLabel: 'नातेसंबंध आणि लैंगिक आरोग्य',
    color: 'bg-rose-100 text-rose-900 border-rose-300 dark:bg-rose-950/60 dark:text-rose-200',
    iconName: 'Heart',
    isHealthCategory: true,
    description: 'निरोगी नातेसंबंध, सुसंवाद, संमती व सुरक्षितता, लैंगिक साक्षरता आणि मानसिक जवळीक',
    subcategories: [
      'Healthy relationships (नातेसंबंध जपण्याच्या टिप्स)',
      'Communication (जोडीदारातील संवाद)',
      'Consent and safety (संमती व वैयक्तिक सुरक्षितता)',
      'Sexual health education (लैंगिक आरोग्य साक्षरता)',
      'Intimacy and wellbeing (मानसिक व भावनिक जवळीक)'
    ]
  },
  {
    id: 'mind_soul',
    englishLabel: 'Mind & Soul',
    marathiLabel: 'मन आणि आत्मिक स्वास्थ्य',
    color: 'bg-violet-100 text-violet-800 border-violet-300 dark:bg-violet-950/60 dark:text-violet-300',
    iconName: 'Smile',
    description: 'माइंडफुलनेस, ताणतणाव व्यवस्थापन, आत्मपरीक्षण, अध्यात्मिक स्वास्थ्य आणि भावनिक ताकद',
    subcategories: [
      'Mindfulness (ध्यान व माइंडफुलनेस)',
      'Stress management (ताणतणाव कमी करण्याचे मार्ग)',
      'Self-reflection (आत्मपरीक्षण व सकारात्मकता)',
      'Spiritual wellbeing (आत्मिक शांतता)',
      'Emotional resilience (भावनिक ताकद)'
    ]
  },
  {
    id: 'inspirational',
    englishLabel: 'Inspirational',
    marathiLabel: 'प्रेरणादायी कथा',
    color: 'bg-amber-200 text-amber-900 border-amber-400 dark:bg-amber-950/80 dark:text-amber-200',
    iconName: 'Trophy',
    description: 'कर्तृत्ववान महिला, जिद्दीचा प्रवास, करिअर यश, सामाजिक कार्य आणि सत्य प्रेरणादायी कथा',
    subcategories: [
      'Women achievers (यशस्वी महिलांच्या कथा)',
      'Personal journeys (संघर्षातून जिद्दीचा प्रवास)',
      'Career achievements (करिअरमधील उत्तुंग यश)',
      'Community initiatives (सामाजिक बदल घडवणाऱ्या व्यक्ती)',
      'Verified human-interest stories (सत्य प्रेरणादायी घडामोडी)'
    ]
  },
  {
    id: 'gardening',
    englishLabel: 'Gardening',
    marathiLabel: 'बागकाम',
    color: 'bg-green-100 text-green-800 border-green-300 dark:bg-green-950/60 dark:text-green-300',
    iconName: 'Flower2',
    description: 'गॅलरी बागकाम, इनडोअर रोपे, सेंद्रिय परसबाग, भाज्यांची बाग आणि झाडांची निगा',
    subcategories: [
      'Balcony gardening (गॅलरीतील बागकाम)',
      'Indoor plants (घरातील शोभेची झाडे)',
      'Seasonal gardening (ऋतूनुसार रोपांची निगा)',
      'Kitchen gardens (घरगुती सेंद्रिय भाज्या)',
      'Plant care (झाडांसाठी खत व पाणी)'
    ]
  },
  {
    id: 'videos',
    englishLabel: 'Videos',
    marathiLabel: 'व्हिडिओ',
    color: 'bg-cyan-100 text-cyan-800 border-cyan-300 dark:bg-cyan-950/60 dark:text-cyan-300',
    iconName: 'Video',
    description: 'व्हिडिओ एक्सप्लेनर, ट्यूटोरियल्स, मुलाखती, प्रात्यक्षिके आणि शॉर्ट-फॉर्म संपादकीय व्हिडिओ',
    subcategories: [
      'Video explainers (माहितीपूर्ण व्हिडिओ)',
      'Tutorials (स्टेप-बाय-स्टेप ट्यूटोरियल्स)',
      'Interviews (विशेष मुलाखती)',
      'Demonstrations (प्रात्यक्षिके व डेमो)',
      'Short-form editorial videos (शॉर्ट्स व रील्स आयडिया)'
    ]
  },
  {
    id: 'photos',
    englishLabel: 'Photos',
    marathiLabel: 'छायाचित्रे',
    color: 'bg-orange-100 text-orange-800 border-orange-300 dark:bg-orange-950/60 dark:text-orange-300',
    iconName: 'Image',
    description: 'फोटो स्टोरीज, सणांचे फोटो गॅलरी, फॅशन गॅलरी, पर्यटन फोटो फीचर्स आणि डॉक्युमेंटेड व्हिज्युअल्स',
    subcategories: [
      'Photo stories (छायाचित्र कथन)',
      'Festival galleries (सण-उत्सव फोटो गॅलरी)',
      'Fashion galleries (फॅशन व ट्रेंड गॅलरी)',
      'Travel galleries (पर्यटन फोटो फिचर)',
      'Documented visual features (दृकश्राव्य फिचर्स)'
    ]
  }
];

export const TOPIC_MIX_OPTIONS = [
  { id: 'balanced', label: 'Balanced Evergreen & Trending', description: 'संतुलित — ५०% सदाबहार आणि ५०% ट्रेंडिंग न्यूज' },
  { id: 'evergreen', label: 'Evergreen SEO Focus', description: 'सदाबहार (Evergreen SEO) — दीर्घकाळ वाचल्या जाणाऱ्या गाईड्स' },
  { id: 'trending', label: 'Current Developments Focus', description: 'ताजी घडामोड (Trending News) — सध्याच्या बातम्या व ट्रेन्ड्स' },
  { id: 'seasonal', label: 'Seasonal & Festival Focus', description: 'हंगामी व सण-उत्सव (Seasonal & Festivals) — आगामी सण व ऋतू' }
];

export const GEO_FOCUS_OPTIONS = [
  { id: 'maharashtra', label: 'Maharashtra (महाराष्ट्र)', description: 'पुणे, मुंबई, नाशिक, नागपूर, छत्रपती संभाजीनगर, कोकण, पश्चिम महाराष्ट्र' },
  { id: 'india', label: 'India National (भारत)', description: 'राष्ट्रीय पातळीवरील घडामोडी व ट्रेंड्स' },
  { id: 'global', label: 'Global Marathi Diaspora (वैश्विक)', description: 'परदेशातील मराठी भाषिक समाज' },
  { id: 'custom', label: 'Custom Location / District', description: 'विशेष शहर किंवा जिल्हा केंद्रित' }
];

export const TOPIC_FOCUS_OPTIONS = [
  { id: 'all', label: 'All Types (सर्व प्रकार)', description: 'सर्व प्रकारच्या ब्लॉग फॉरमॅट्सचे संतुलित मिश्रण' },
  { id: 'how_to', label: 'Practical How-To', description: 'हाऊ-टू व सोपे उपाय — पायरी-दर-पायरी मार्गदर्शक व प्रॅक्टिकल सोल्यूशन्स' },
  { id: 'comparison', label: 'Comparison / Review', description: 'तुलना व पुनरावलोकन — वस्तूंची तुलना, मूल्यमापन व खरेदी पर्याय' },
  { id: 'personal_stories', label: 'Personal Stories', description: 'अनुभव व प्रेरणादायी कथा — सत्य अनुभव, जिद्दीचा प्रवास व वैयक्तिक किस्से' },
  { id: 'guides', label: 'Informational Guides', description: 'माहितीपूर्ण गाईड्स — सविस्तर माहिती, विषय समजावून सांगणारे लेख व चेकलिस्ट' }
];
