/**
 * Central Configuration for Gemini API & Application Defaults
 */
export const DEFAULT_GEMINI_MODEL = 'gemini-3.8-flash';
export const DEFAULT_GEMINI_MODEL_LABEL = 'Gemini 3.8 Flash (Default)';
