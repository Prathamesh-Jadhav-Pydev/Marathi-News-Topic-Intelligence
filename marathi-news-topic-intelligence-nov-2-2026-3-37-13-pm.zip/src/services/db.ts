import { TopicRecord, BatchMetadata, ImportedRecord, CategoryId } from '../types';

const DB_NAME = 'MarathiNewsTopicIntelligenceDB';
const DB_VERSION = 1;

class TopicDatabase {
  private dbPromise: Promise<IDBDatabase> | null = null;

  private getDB(): Promise<IDBDatabase> {
    if (this.dbPromise) return this.dbPromise;

    this.dbPromise = new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);

      request.onupgradeneeded = (event) => {
        const db = request.result;

        // Topic Records Store
        if (!db.objectStoreNames.contains('topics')) {
          const topicStore = db.createObjectStore('topics', { keyPath: 'topic_id' });
          topicStore.createIndex('batch_id', 'batch_id', { unique: false });
          topicStore.createIndex('primary_category', 'primary_category', { unique: false });
          topicStore.createIndex('workflow_status', 'workflow_status', { unique: false });
          topicStore.createIndex('duplicate_status', 'duplicate_status', { unique: false });
          topicStore.createIndex('editorial_priority', 'editorial_priority', { unique: false });
          topicStore.createIndex('created_at', 'created_at', { unique: false });
        }

        // Batches Store
        if (!db.objectStoreNames.contains('batches')) {
          db.createObjectStore('batches', { keyPath: 'batch_id' });
        }

        // Imported Records Store
        if (!db.objectStoreNames.contains('imported_records')) {
          const importStore = db.createObjectStore('imported_records', { keyPath: 'id' });
          importStore.createIndex('headline', 'headline', { unique: false });
          importStore.createIndex('url', 'url', { unique: false });
        }

        // Settings Store
        if (!db.objectStoreNames.contains('settings')) {
          db.createObjectStore('settings', { keyPath: 'key' });
        }
      };

      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });

    return this.dbPromise;
  }

  // --- TOPIC METHODS ---

  async getAllTopics(): Promise<TopicRecord[]> {
    const db = await this.getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('topics', 'readonly');
      const store = tx.objectStore('topics');
      const request = store.getAll();
      request.onsuccess = () => resolve(request.result || []);
      request.onerror = () => reject(request.error);
    });
  }

  async getTopicById(topicId: string): Promise<TopicRecord | null> {
    const db = await this.getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('topics', 'readonly');
      const store = tx.objectStore('topics');
      const request = store.get(topicId);
      request.onsuccess = () => resolve(request.result || null);
      request.onerror = () => reject(request.error);
    });
  }

  async saveTopic(topic: TopicRecord): Promise<void> {
    const db = await this.getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('topics', 'readwrite');
      const store = tx.objectStore('topics');
      const request = store.put(topic);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  }

  async saveTopicsBulk(topics: TopicRecord[]): Promise<void> {
    const db = await this.getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('topics', 'readwrite');
      const store = tx.objectStore('topics');
      for (const t of topics) {
        store.put(t);
      }
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }

  async deleteTopic(topicId: string): Promise<void> {
    const db = await this.getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('topics', 'readwrite');
      const store = tx.objectStore('topics');
      const request = store.delete(topicId);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  }

  async deleteBatchTopics(batchId: string): Promise<void> {
    const topics = await this.getAllTopics();
    const batchTopicIds = topics.filter(t => t.batch_id === batchId).map(t => t.topic_id);
    const db = await this.getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(['topics', 'batches'], 'readwrite');
      const topicStore = tx.objectStore('topics');
      const batchStore = tx.objectStore('batches');
      for (const id of batchTopicIds) {
        topicStore.delete(id);
      }
      batchStore.delete(batchId);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }

  // --- BATCH METHODS ---

  async saveBatchMetadata(batch: BatchMetadata): Promise<void> {
    const db = await this.getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('batches', 'readwrite');
      const store = tx.objectStore('batches');
      const request = store.put(batch);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  }

  async getAllBatches(): Promise<BatchMetadata[]> {
    const db = await this.getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('batches', 'readonly');
      const store = tx.objectStore('batches');
      const request = store.getAll();
      request.onsuccess = () => resolve(request.result || []);
      request.onerror = () => reject(request.error);
    });
  }

  // --- IMPORTED RECORDS METHODS ---

  async saveImportedRecords(records: ImportedRecord[]): Promise<void> {
    const db = await this.getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('imported_records', 'readwrite');
      const store = tx.objectStore('imported_records');
      for (const rec of records) {
        store.put(rec);
      }
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }

  async getAllImportedRecords(): Promise<ImportedRecord[]> {
    const db = await this.getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('imported_records', 'readonly');
      const store = tx.objectStore('imported_records');
      const request = store.getAll();
      request.onsuccess = () => resolve(request.result || []);
      request.onerror = () => reject(request.error);
    });
  }

  // --- SETTINGS & SUBCATEGORIES ---

  async getSetting<T>(key: string): Promise<T | null> {
    const db = await this.getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('settings', 'readonly');
      const store = tx.objectStore('settings');
      const request = store.get(key);
      request.onsuccess = () => resolve(request.result ? request.result.value : null);
      request.onerror = () => reject(request.error);
    });
  }

  async saveSetting<T>(key: string, value: T): Promise<void> {
    const db = await this.getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('settings', 'readwrite');
      const store = tx.objectStore('settings');
      const request = store.put({ key, value });
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  }

  async clearAll(): Promise<void> {
    const db = await this.getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(['topics', 'batches', 'imported_records'], 'readwrite');
      tx.objectStore('topics').clear();
      tx.objectStore('batches').clear();
      tx.objectStore('imported_records').clear();
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }
}

export const topicDB = new TopicDatabase();
