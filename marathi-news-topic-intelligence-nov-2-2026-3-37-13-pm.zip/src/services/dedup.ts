import { TopicRecord, DuplicateMatch, DuplicateStatus, ImportedRecord } from '../types';

/**
 * Normalizes Marathi/English text by lowercasing, stripping punctuation,
 * removing zero-width joiners, and trimming whitespace.
 */
export function normalizeText(text: string): string {
  if (!text) return '';
  return text
    .toLowerCase()
    .replace(/[\u200B-\u200D\uFEFF]/g, '') // strip zero-width characters
    .replace(/[^\p{L}\p{N}\s]/gu, ' ')     // replace punctuation with space
    .replace(/\s+/g, ' ')                  // collapse whitespace
    .trim();
}

/**
 * Strips years (2024, 2025, 2026, २०२४, २०२५, २०२६), numbers, dates,
 * and superficial template filler words to extract the underlying semantic concept stem.
 */
export function extractSemanticCoreStem(text: string): string {
  if (!text) return '';
  let norm = normalizeText(text);

  // Strip 4-digit years (English & Devanagari)
  norm = norm.replace(/\b(202[0-9]|203[0-9]|२०२[०-९]|२०३[०-९])\b/g, '');

  // Strip numbers
  norm = norm.replace(/\b[0-9०-९]+\b/g, '');

  // Strip superficial template modifiers & filler words
  const fillers = [
    'नवीन', 'ताजी', 'खास', 'विशेष', 'सर्वोत्कृष्ट', 'महत्त्वाचे', 'महत्त्वाच्या', 'संपूर्ण',
    'मार्गदर्शक', 'टिप्स', 'उपाय', 'गोष्टी', 'माहिती', 'काय', 'कसे', 'का', 'जाणून', 'घ्या',
    'बदल', 'सोपे', 'मार्ग', 'नियम', 'साधने', 'गाइड', 'guide', 'tips', 'best', 'top', 'latest'
  ];

  const words = norm.split(' ').filter(w => w.length > 1 && !fillers.includes(w));
  return words.join(' ').trim();
}

/**
 * Generates word n-grams (default 1-grams and 2-grams) for similarity checks.
 */
function getWordNgrams(normalizedText: string): Set<string> {
  const words = normalizedText.split(' ').filter(w => w.length > 1);
  const ngrams = new Set<string>();

  for (let i = 0; i < words.length; i++) {
    ngrams.add(words[i]);
    if (i < words.length - 1) {
      ngrams.add(`${words[i]}_${words[i + 1]}`);
    }
  }
  return ngrams;
}

/**
 * Calculates Jaccard similarity between two sets of n-grams.
 */
export function calculateJaccardSimilarity(textA: string, textB: string): number {
  const normA = extractSemanticCoreStem(textA) || normalizeText(textA);
  const normB = extractSemanticCoreStem(textB) || normalizeText(textB);

  if (!normA || !normB) return 0;
  if (normA === normB) return 1.0;

  const ngramsA = getWordNgrams(normA);
  const ngramsB = getWordNgrams(normB);

  let intersectionCount = 0;
  for (const item of ngramsA) {
    if (ngramsB.has(item)) intersectionCount++;
  }

  const unionCount = ngramsA.size + ngramsB.size - intersectionCount;
  if (unionCount === 0) return 0;

  return intersectionCount / unionCount;
}

/**
 * Evaluates a topic record against a list of existing topics and imported records.
 */
export function checkDuplicateStatus(
  candidateTopic: Partial<TopicRecord>,
  existingTopics: TopicRecord[],
  importedRecords: ImportedRecord[] = []
): { duplicate_status: DuplicateStatus; matches: DuplicateMatch[] } {
  const matches: DuplicateMatch[] = [];

  const candidateHeadline = candidateTopic.primary_headline || candidateTopic.topic_title || '';
  const normCandHeadline = normalizeText(candidateHeadline);
  const candidateKeywords = (candidateTopic.primary_keyword || '').toLowerCase();
  const candidateSummary = candidateTopic.topic_summary || candidateTopic.detailed_article_context || '';

  // 1. Check against existing topics
  for (const existing of existingTopics) {
    if (existing.topic_id === candidateTopic.topic_id) continue; // Skip self

    const existHeadline = existing.primary_headline || existing.topic_title || '';
    const normExistHeadline = normalizeText(existHeadline);

    // Exact or Normalized Headline Match
    if (normCandHeadline && normCandHeadline === normExistHeadline) {
      matches.push({
        matchedTopicId: existing.topic_id,
        matchedHeadline: existHeadline,
        matchedUrl: existing.published_url,
        reason: 'हुबेहूब किंवा समान शीर्षक आढळले (Exact Headline Match)',
        similarityScore: 1.0,
        matchedType: 'exact_headline'
      });
      continue;
    }

    // Headline Similarity via Jaccard
    const headlineSim = calculateJaccardSimilarity(candidateHeadline, existHeadline);
    if (headlineSim >= 0.50) {
      matches.push({
        matchedTopicId: existing.topic_id,
        matchedHeadline: existHeadline,
        matchedUrl: existing.published_url,
        reason: `शीर्षक आणि विषयामध्ये उच्च साम्य (${Math.round(headlineSim * 100)}%)`,
        similarityScore: headlineSim,
        matchedType: 'normalized_headline'
      });
      continue;
    }

    // Search Intent & Brief Similarity check
    if (
      candidateTopic.primary_category === existing.primary_category &&
      candidateTopic.primary_keyword &&
      existing.primary_keyword &&
      normalizeText(candidateTopic.primary_keyword) === normalizeText(existing.primary_keyword)
    ) {
      const summarySim = calculateJaccardSimilarity(candidateSummary, existing.topic_summary || '');
      const score = Math.max(0.65, summarySim);
      matches.push({
        matchedTopicId: existing.topic_id,
        matchedHeadline: existHeadline,
        matchedUrl: existing.published_url,
        reason: 'समान प्रायमरी कीवर्ड आणि सर्च इंटेंट (Matching Intent & Keywords)',
        similarityScore: score,
        matchedType: 'intent_overlap'
      });
    }
  }

  // 2. Check against imported records (URLs and existing headlines)
  for (const imp of importedRecords) {
    const impHeadline = imp.headline || '';
    const normImpHeadline = normalizeText(impHeadline);

    if (normCandHeadline && normCandHeadline === normImpHeadline) {
      matches.push({
        matchedHeadline: impHeadline,
        matchedUrl: imp.url,
        reason: 'इम्पोर्ट केलेल्या डाटाबेसमध्ये हे शीर्षक आधीपासून उपलब्ध आहे',
        similarityScore: 1.0,
        matchedType: 'imported_url'
      });
      continue;
    }

    const sim = calculateJaccardSimilarity(candidateHeadline, impHeadline);
    if (sim >= 0.55) {
      matches.push({
        matchedHeadline: impHeadline,
        matchedUrl: imp.url,
        reason: `इम्पोर्ट केलेल्या लेखाच्या शीर्षकाशी ${Math.round(sim * 100)}% साम्य`,
        similarityScore: sim,
        matchedType: 'imported_url'
      });
    }
  }

  // Sort matches by highest similarity score
  matches.sort((a, b) => b.similarityScore - a.similarityScore);

  const highestScore = matches.length > 0 ? matches[0].similarityScore : 0;

  let duplicate_status: DuplicateStatus = 'unique';
  if (highestScore >= 0.70) {
    duplicate_status = 'confirmed_duplicate';
  } else if (highestScore >= 0.35) {
    duplicate_status = 'possible_duplicate';
  }

  return { duplicate_status, matches };
}

const CATEGORY_SUBJECT_KEYWORDS: Record<string, string[]> = {
  travel: ['ट्रिप', 'पर्यटन', 'किल्ले', 'ट्रेकिंग', 'समुद्रकिनारा', 'धबधबा', 'सहली', 'गेटवे', 'भ्रमंती', 'पावसाळी सहल', 'travel', 'trip', 'fort'],
  health: ['आरोग्य', 'प्रतिकारशक्ती', 'आजार', 'आयुर्वेदिक', 'डॉक्टर', 'वैद्यकीय', 'स्वास्थ्याभ्यास', 'निसर्गोपचार', 'health', 'immunity', 'disease'],
  parenting: ['मुलां', 'स्क्रीन टाईम', 'अभ्यास', 'पालक', 'संगोपन', 'बालसंगोपन', 'child', 'parenting', 'screen time', 'kids'],
  food: ['नाश्ता', 'रेसिपी', 'पाककृती', 'नैवेद्य', 'पदार्थ', 'स्वादिष्ट', 'रस्सा', 'recipe', 'food', 'cooking'],
  fashion: ['कपडे', 'फॅशन', 'साडी', 'पैठणी', 'दागिने', 'लुक', 'fashion', 'outfit', 'saree', 'jewelry'],
  devotional: ['पूजा', 'व्रत', 'अष्टविनायक', 'मंत्र', 'आरती', 'ज्योतिर्लिंग', 'puja', 'devotional', 'temple'],
  home_decor: ['गृहसजावट', 'बाल्कनी', 'परसबाग', 'इंटीरिअर', 'रांगोळी', 'decor', 'home', 'interior'],
  weight_loss_diet: ['वजन कमी', 'डाएट', 'कॅलरी', 'प्रोटीन', 'पोट कमी', 'diet', 'weight loss', 'calories'],
  women: ['गृहउद्योग', 'महिला', 'उद्योजकता', 'मातृत्व', 'स्वयंसिद्धता', 'women', 'entrepreneurship'],
  pregnancy: ['गर्भारपण', 'गरोदरपण', 'मॉर्निंग सिकनेस', 'सोनोग्राफी', 'pregnancy', 'prenatal'],
};

const CATEGORY_LABELS: Record<string, string> = {
  travel: 'प्रवास आणि पर्यटन',
  health: 'आरोग्य',
  parenting: 'पालकत्व',
  food: 'खाद्यसंस्कृती आणि पाककृती',
  fashion: 'फॅशन',
  devotional: 'अध्यात्म आणि भक्ती',
  home_decor: 'घर आणि सजावट',
  weight_loss_diet: 'वजन कमी करणे आणि आहार',
  women: 'महिला',
  pregnancy: 'गर्भधारणा',
};

/**
 * Validates category compatibility against the actual headline subject.
 * If a mismatch is found, returns a warning string while keeping original category/keywords intact.
 */
export function detectCategoryMismatch(headline: string, selectedCategory: string): string | undefined {
  if (!headline || !selectedCategory) return undefined;

  const lowerHeadline = headline.toLowerCase();

  for (const [catKey, keywords] of Object.entries(CATEGORY_SUBJECT_KEYWORDS)) {
    if (catKey === selectedCategory) continue;

    const matchedKw = keywords.find(kw => lowerHeadline.includes(kw));
    if (matchedKw) {
      const suggestedLabel = CATEGORY_LABELS[catKey] || catKey;
      const selectedLabel = CATEGORY_LABELS[selectedCategory] || selectedCategory;
      return `⚠️ श्रेणी विसंगती: विषयाचा मुख्य गाभा '${suggestedLabel}' (${matchedKw}) या श्रेणीशी अधिक सुसंगत वाटतो, परंतु निवडलेली श्रेणी '${selectedLabel}' आहे.`;
    }
  }

  return undefined;
}
