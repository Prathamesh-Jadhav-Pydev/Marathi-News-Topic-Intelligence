import Papa from 'papaparse';
import { TopicRecord, SourceCitation, ImportedRecord } from '../types';

/**
 * Sanitizes untrusted text strings to prevent formula injection in spreadsheets (e.g. Excel).
 */
export function sanitizeSpreadsheetValue(value: unknown): string {
  if (value === null || value === undefined) return '';
  let str = String(value).trim();
  // Prevent formula execution if string starts with =, +, -, @, or tab/CR
  if (/^[=+\-@\t\r]/.test(str)) {
    str = `'${str}`;
  }
  return str;
}

/**
 * Converts array of values into a semicolon-separated or comma-separated clean string.
 */
function formatArrayField(arr?: string[]): string {
  if (!arr || !Array.isArray(arr) || arr.length === 0) return '';
  return arr.map(item => sanitizeSpreadsheetValue(item)).join('; ');
}

/**
 * Formats sources array into a readable summary string for standard CSV rows.
 */
function formatSourcesField(sources?: SourceCitation[]): string {
  if (!sources || !Array.isArray(sources) || sources.length === 0) return '';
  return sources
    .map(s => `${s.title} (${s.publisherDomain || s.url})`)
    .join(' | ');
}

/**
 * Exports topic records to a UTF-8 BOM encoded CSV file.
 */
export function exportTopicsToCSV(topics: TopicRecord[], filename: string = 'marathi_news_topics.csv'): void {
  const headers = [
    'Topic ID',
    'Primary Category',
    'Subcategory',
    'Topic Title',
    'Primary Headline (मराठी शीर्षक)',
    'Alternate Headline 1',
    'Alternate Headline 2',
    'Topic Summary',
    'Primary Keyword',
    'Secondary Keywords',
    'Search Intent Type',
    'Evergreen or Trending',
    'Editorial Priority',
    'Confidence Score',
    'Research Status',
    'Workflow Status',
    'Duplicate Status',
    'Suggested Slug',
    'Meta Description',
    'Key Questions to Answer',
    'Suggested Article Outline',
    'Unique Editorial Angle',
    'Content Format',
    'Sources Count',
    'Sources Summary',
    'Created At'
  ];

  const rows = topics.map(t => [
    sanitizeSpreadsheetValue(t.topic_id),
    sanitizeSpreadsheetValue(t.primary_category),
    sanitizeSpreadsheetValue(t.subcategory),
    sanitizeSpreadsheetValue(t.topic_title),
    sanitizeSpreadsheetValue(t.primary_headline),
    sanitizeSpreadsheetValue(t.alternate_headlines?.[0] || ''),
    sanitizeSpreadsheetValue(t.alternate_headlines?.[1] || ''),
    sanitizeSpreadsheetValue(t.topic_summary),
    sanitizeSpreadsheetValue(t.primary_keyword),
    formatArrayField(t.secondary_keywords),
    sanitizeSpreadsheetValue(t.search_intent_type),
    sanitizeSpreadsheetValue(t.evergreen_or_trending),
    sanitizeSpreadsheetValue(t.editorial_priority),
    sanitizeSpreadsheetValue(t.confidence_score),
    sanitizeSpreadsheetValue(t.research_status),
    sanitizeSpreadsheetValue(t.workflow_status),
    sanitizeSpreadsheetValue(t.duplicate_status),
    sanitizeSpreadsheetValue(t.suggested_slug),
    sanitizeSpreadsheetValue(t.suggested_meta_description),
    formatArrayField(t.key_questions_to_answer),
    formatArrayField(t.suggested_article_outline),
    sanitizeSpreadsheetValue(t.unique_editorial_angle),
    sanitizeSpreadsheetValue(t.recommended_content_format),
    sanitizeSpreadsheetValue(t.sources?.length || 0),
    formatSourcesField(t.sources),
    sanitizeSpreadsheetValue(t.created_at)
  ]);

  const csvContent = Papa.unparse([headers, ...rows]);
  // Prepend UTF-8 BOM so Excel opens Marathi Marathi Devnagari script correctly
  const blob = new Blob(['\uFEFF' + csvContent], { type: 'text/csv;charset=utf-8;' });
  downloadBlob(blob, filename);
}

/**
 * Exports dedicated Research Sources report to CSV.
 */
export function exportSourcesToCSV(topics: TopicRecord[], filename: string = 'marathi_news_research_sources.csv'): void {
  const headers = [
    'Source ID',
    'Topic ID',
    'Primary Headline',
    'Category',
    'Source Title',
    'URL',
    'Publisher Domain',
    'Publication Date',
    'Access Date',
    'Supported Claim',
    'Verification Status'
  ];

  const rows: string[][] = [];

  for (const topic of topics) {
    if (topic.sources && topic.sources.length > 0) {
      for (const source of topic.sources) {
        rows.push([
          sanitizeSpreadsheetValue(source.id),
          sanitizeSpreadsheetValue(topic.topic_id),
          sanitizeSpreadsheetValue(topic.primary_headline),
          sanitizeSpreadsheetValue(topic.primary_category),
          sanitizeSpreadsheetValue(source.title),
          sanitizeSpreadsheetValue(source.url),
          sanitizeSpreadsheetValue(source.publisherDomain),
          sanitizeSpreadsheetValue(source.publicationDate || ''),
          sanitizeSpreadsheetValue(source.accessDate),
          sanitizeSpreadsheetValue(source.claimSupported),
          sanitizeSpreadsheetValue(source.verificationStatus)
        ]);
      }
    }
  }

  const csvContent = Papa.unparse([headers, ...rows]);
  const blob = new Blob(['\uFEFF' + csvContent], { type: 'text/csv;charset=utf-8;' });
  downloadBlob(blob, filename);
}

/**
 * Exports complete JSON nested records.
 */
export function exportTopicsToJSON(topics: TopicRecord[], filename: string = 'marathi_news_topics.json'): void {
  const jsonStr = JSON.stringify(topics, null, 2);
  const blob = new Blob([jsonStr], { type: 'application/json;charset=utf-8;' });
  downloadBlob(blob, filename);
}

function downloadBlob(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.setAttribute('download', filename);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

/**
 * Interface for column mapping during import.
 */
export interface ColumnMapping {
  headlineField: string;
  urlField: string;
  categoryField: string;
  subcategoryField: string;
  pubDateField: string;
  keywordField: string;
  contentField: string;
  statusField: string;
}

export interface ImportParseResult {
  records: ImportedRecord[];
  errors: { row: number; error: string; data?: unknown }[];
  totalParsed: number;
}

/**
 * Parses CSV or JSON content for importing existing published/planned articles.
 */
export function parseImportFile(
  fileContent: string,
  isJson: boolean,
  mapping: ColumnMapping
): ImportParseResult {
  const records: ImportedRecord[] = [];
  const errors: { row: number; error: string; data?: unknown }[] = [];

  if (isJson) {
    try {
      const parsed = JSON.parse(fileContent);
      const items = Array.isArray(parsed) ? parsed : [parsed];
      items.forEach((item, index) => {
        const headline = item[mapping.headlineField] || item.headline || item.title || item.primary_headline;
        if (!headline || typeof headline !== 'string') {
          errors.push({ row: index + 1, error: 'शीर्षक (Headline) रिकामा किंवा अवैध आहे', data: item });
          return;
        }

        records.push({
          id: `imp-${Date.now()}-${index}`,
          headline: headline.trim(),
          url: item[mapping.urlField] || item.url || item.published_url || '',
          category: item[mapping.categoryField] || item.category || '',
          subcategory: item[mapping.subcategoryField] || item.subcategory || '',
          publication_date: item[mapping.pubDateField] || item.publication_date || item.created_at || '',
          primary_keyword: item[mapping.keywordField] || item.primary_keyword || '',
          article_content: item[mapping.contentField] || item.content || item.topic_summary || '',
          status: item[mapping.statusField] || item.status || 'imported',
          imported_at: new Date().toISOString()
        });
      });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Invalid JSON file format';
      errors.push({ row: 0, error: `JSON पार्सिंग त्रुटी: ${msg}` });
    }
  } else {
    // CSV Parsing via PapaParse
    const parsed = Papa.parse<Record<string, string>>(fileContent, {
      header: true,
      skipEmptyLines: true
    });

    if (parsed.errors && parsed.errors.length > 0) {
      parsed.errors.forEach(e => {
        errors.push({ row: e.row || 0, error: e.message });
      });
    }

    parsed.data.forEach((row, index) => {
      const headline = row[mapping.headlineField];
      if (!headline || !headline.trim()) {
        errors.push({ row: index + 2, error: 'शीर्षक कॉलम रिकामी आहे', data: row });
        return;
      }

      records.push({
        id: `imp-${Date.now()}-${index}`,
        headline: headline.trim(),
        url: row[mapping.urlField] ? row[mapping.urlField].trim() : '',
        category: row[mapping.categoryField] ? row[mapping.categoryField].trim() : '',
        subcategory: row[mapping.subcategoryField] ? row[mapping.subcategoryField].trim() : '',
        publication_date: row[mapping.pubDateField] ? row[mapping.pubDateField].trim() : '',
        primary_keyword: row[mapping.keywordField] ? row[mapping.keywordField].trim() : '',
        article_content: row[mapping.contentField] ? row[mapping.contentField].trim() : '',
        status: row[mapping.statusField] ? row[mapping.statusField].trim() : 'imported',
        imported_at: new Date().toISOString()
      });
    });
  }

  return {
    records,
    errors,
    totalParsed: records.length + errors.length
  };
}
