export type CategoryId =
  // Original 12
  | 'lifestyle'
  | 'fashion'
  | 'devotional'
  | 'women'
  | 'health'
  | 'astrology'
  | 'parenting'
  | 'food'
  | 'entertainment'
  | 'culture_tradition'
  | 'home_decor'
  | 'travel'
  // 18 Additional
  | 'pregnancy'
  | 'adolescence'
  | 'infertility'
  | 'family_planning'
  | 'gynaecological_disorders'
  | 'menopause'
  | 'menstrual_cycle'
  | 'anaemia'
  | 'fitness'
  | 'weight_loss_diet'
  | 'beauty'
  | 'shopping'
  | 'relationships_sexual_health'
  | 'mind_soul'
  | 'inspirational'
  | 'gardening'
  | 'videos'
  | 'photos';

export interface CategoryDef {
  id: CategoryId;
  englishLabel: string;
  marathiLabel: string;
  subcategories: string[];
  description: string;
  color: string;
  iconName: string;
  isHealthCategory?: boolean;
  isDisabled?: boolean;
  parentId?: CategoryId;
}

export type TopicMixOption = 'balanced' | 'evergreen' | 'trending' | 'seasonal';
export type ResearchMode = 'deep' | 'standard' | 'fast';
export type GeoFocus = 'maharashtra' | 'india' | 'global' | 'custom';

export type SearchIntentType = 'informational' | 'transactional' | 'navigational' | 'commercial' | 'explainer';
export type EvergreenOrTrending = 'evergreen' | 'trending' | 'seasonal';
export type ResearchStatus = 'verified' | 'partially_verified' | 'needs_verification' | 'research_unavailable';
export type EditorialPriority = 'high' | 'medium' | 'low';
export type EstimatedEffort = 'low' | 'medium' | 'high';
export type TimelinessLabel = 'current' | 'seasonal' | 'evergreen' | 'expiring';
export type DuplicateStatus = 'unique' | 'possible_duplicate' | 'confirmed_duplicate';
export type WorkflowStatus = 'idea' | 'under_review' | 'approved' | 'assigned' | 'published' | 'rejected';

export interface SourceCitation {
  id: string;
  title: string;
  url: string;
  publisherDomain: string;
  publicationDate?: string;
  accessDate: string;
  claimSupported: string;
  verificationStatus: ResearchStatus;
}

export interface DuplicateMatch {
  matchedTopicId?: string;
  matchedHeadline?: string;
  matchedUrl?: string;
  reason: string;
  similarityScore: number; // 0 to 1
  matchedType: 'exact_headline' | 'normalized_headline' | 'intent_overlap' | 'brief_similarity' | 'imported_url';
}

export interface TopicRecord {
  // Identification
  topic_id: string;
  batch_id: string;
  created_at: string;
  output_language: string; // Defaults to "mr" (Marathi)
  primary_category: CategoryId;
  subcategory: string;
  topic_title: string;
  primary_headline: string;
  alternate_headlines: [string, string]; // Exactly 2 alternate headlines
  topic_summary: string;

  // Editorial Brief
  detailed_article_context: string;
  article_objective: string;
  reader_intent: string;
  target_audience: string;
  key_questions_to_answer: string[];
  suggested_article_outline: string[];
  unique_editorial_angle: string;
  recommended_content_format: string;
  internal_linking_suggestions: string;
  editorial_notes: string;

  // SEO Fields
  primary_keyword: string;
  secondary_keywords: string[];
  related_entities: string[];
  suggested_slug: string;
  search_intent_type: SearchIntentType;
  evergreen_or_trending: EvergreenOrTrending;
  seasonal_relevance: string;
  suggested_meta_description: string;
  seo_opportunity_rationale: string;

  // Research Fields
  research_status: ResearchStatus;
  research_evidence_summary: string; // What sources actually establish
  sources: SourceCitation[];
  search_queries_used: string[]; // Queries used during grounding
  verified_facts: string[];
  claims_requiring_verification: string[];
  verification_requirements: string[];
  verification_checklist: string[]; // Pre-publication checklist
  research_summary: string;
  last_researched_at: string;
  freshness_notes: string;

  // Medical Safety
  medical_verification_required: boolean;
  medical_disclaimer?: string;

  // Prioritisation
  editorial_priority: EditorialPriority;
  priority_rationale: string;
  estimated_effort: EstimatedEffort;
  timeliness_label: TimelinessLabel;
  time_sensitivity_notes: string;
  confidence_score: number; // 0 - 100
  manual_review_required: boolean;

  // Deduplication & Workflow
  duplicate_status: DuplicateStatus;
  duplicate_matches: DuplicateMatch[];
  category_mismatch_warning?: string;
  workflow_status: WorkflowStatus;
  editor_notes: string;
  assigned_writer?: string;
  published_url?: string;
  last_updated_at: string;
}

export type TopicFocusOption = 'all' | 'how_to' | 'comparison' | 'personal_stories' | 'guides';

export interface BatchSettings {
  batch_id: string;
  categories: CategoryId[];
  subcategories: Record<string, string[]>;
  batch_size: number;
  topic_mix: TopicMixOption;
  topic_focus?: TopicFocusOption;
  research_mode: ResearchMode;
  geo_focus: GeoFocus;
  custom_geo?: string;
  audience_focus: string;
  seed_keywords: string[];
  excluded_subjects: string[];
  custom_instructions?: string;
  language: string;
}

export interface BatchMetadata {
  batch_id: string;
  created_at: string;
  settings: BatchSettings;
  requested_count: number;
  generated_count: number;
  verified_count: number;
  duplicate_rejected_count: number;
  malformed_rejected_count: number;
  replacement_generated_count: number;
  status: 'running' | 'paused' | 'completed' | 'failed';
  current_stage: string;
  error_message?: string;
  logs: string[];
}

export interface ImportedRecord {
  id: string;
  headline: string;
  url?: string;
  category?: string;
  subcategory?: string;
  publication_date?: string;
  primary_keyword?: string;
  article_content?: string;
  status?: string;
  imported_at: string;
}

export interface FilterOptions {
  searchQuery: string;
  primaryCategory: string;
  subcategory: string;
  evergreenOrTrending: string;
  searchIntent: string;
  researchStatus: string;
  editorialPriority: string;
  timelinessLabel: string;
  duplicateStatus: string;
  workflowStatus: string;
  medicalVerificationOnly: boolean;
  dateRange: 'all' | 'today' | 'week' | 'month';
}
