/**
 * Safe fetch helper for JSON API requests to avoid "Unexpected token '<' JSON Parsing Error".
 * Validates Content-Type, HTTP status, and safely parses JSON response.
 */
export async function safeFetchJson<T = any>(url: string, options?: RequestInit): Promise<T> {
  const response = await fetch(url, options);

  const contentType = response.headers.get('content-type') || '';
  const responseText = await response.text();

  // Validate content-type is JSON
  if (!contentType.includes('application/json')) {
    const statusInfo = `HTTP ${response.status} ${response.statusText}`;
    const preview = responseText.slice(0, 150).replace(/\s+/g, ' ');
    console.error(`Unexpected non-JSON response from ${url} [${statusInfo}]:`, preview);
    throw new Error(`Server returned non-JSON response (${statusInfo}). Expected application/json but received '${contentType}'. Response preview: ${preview}`);
  }

  // Parse JSON safely
  let data: any;
  try {
    data = JSON.parse(responseText);
  } catch (parseError: any) {
    console.error(`JSON parse failed for response from ${url}:`, parseError);
    throw new Error(`Failed to parse JSON response from ${url}: ${parseError.message}`);
  }

  // Check HTTP status code
  if (!response.ok) {
    const errorMsg = data?.error || data?.message || `Server HTTP Error ${response.status} (${response.statusText})`;
    throw new Error(errorMsg);
  }

  return data as T;
}
